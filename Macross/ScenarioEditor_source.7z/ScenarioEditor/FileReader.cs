﻿using System.Collections.Generic;
using System.IO;
using System.Runtime.InteropServices;

namespace ScenarioEditor {
    public class FileReader {
        private byte[] barray;
        
        private int seek;
        public ushort Seek { get { return (ushort) seek; } }
        public ushort Length { get { return (ushort) barray.Length; } }
        public string Filename { get; private set; }

        public FileReader(string path) {
            Filename = Path.GetFileName(path);
            barray = File.ReadAllBytes(path);
            seek = 0;
        }

        public byte ReadByte() {
            if (seek >= barray.Length) return 0;
            return barray[seek++];
        }

        public byte PeekByte() {
            if (seek >= barray.Length) return 0;
            return barray[seek];
        }

        public byte[] ReadBytes(int n) {
            var ret = new byte[n];
            if (seek >= barray.Length) return ret;
            for (var i = 0; i < n; i++) {
                ret[i] = ReadByte();
            }
            return ret;
        }

        public string ReadCstring() {
            if (seek >= barray.Length) return "";
            var buf = new List<byte>();
            byte b;
            do {
                b = ReadByte();
                if (b != 0) buf.Add(b);
            } while (b > 0);
            return DecodeString(buf);
        }

        public static string DecodeString(List<byte> buf) {
            var encoder = System.Text.Encoding.GetEncoding("shift-jis");
            return encoder.GetString(buf.ToArray());
        }

        public static byte[] EncodeString(string str) {
            var encoder = System.Text.Encoding.GetEncoding("shift-jis");
            return encoder.GetBytes(str);
        }

        public string ReadEstring() {
            if (seek >= barray.Length) return "";
            var buf = new List<byte>();
            while (barray[seek] != 0x5c || barray[seek + 1] != 0x45) {
                buf.Add(barray[seek]);
                seek++;
            }
            buf.Add(ReadByte());
            buf.Add(ReadByte());
            return DecodeString(buf);
        }

        public ushort ReadUint16() {
            if (seek >= barray.Length) return 0;
            var b1 = ReadByte();
            var b2 = ReadByte();
            return (ushort) ((b2 << 8) | b1);
        }
    }
}