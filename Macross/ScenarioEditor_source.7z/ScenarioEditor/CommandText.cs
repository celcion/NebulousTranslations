﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;

namespace ScenarioEditor
{
    public class OutputString : Command
    {
        private byte[] args;
        private byte strNum;
        private string[] strings;

        public OutputString(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = true;
            IsMultiline = true;
            args = reader.ReadBytes(10);
            ArgX = args[0];
            ArgY = (ushort) ((args[2] << 8) + args[1]);
            ArgVSpace = (ushort)((args[4] << 8) + args[3]);
            ArgSize = args[5];
            ArgFont = args[6];
            strNum = ArgStrings = args[7];
            strings = new string[strNum];
            ActionData = args;
            for (var i = 0; i < strNum; i++) {
                strings[i] = reader.ReadCstring();
                ActionData = ActionData.Concat(FileReader.EncodeString(strings[i])).Concat(new byte[] {0}).ToArray();
            }
        }

        public byte ArgX { get; set; }

        public ushort ArgY { get; set; }

        public ushort ArgVSpace { get; set; }

        public byte ArgSize { get; set; }

        public byte ArgFont { get; set; }

        public byte ArgStrings { get; set; }

        public override string ToString() {
            return $"[{Offset:X4}]\t{string.Join("\t\r\n", strings)}";
        }

        public override string Text() {
            return string.Join("[NL]", strings);
        }

        public override string[] OriginalTextMultiline() {
            return strings;
        }

        public override byte[] Compile() {
            var text = string.IsNullOrEmpty(Translation) ? strings : Translation.Split(new[] {"[NL]"}, StringSplitOptions.None);
            var ret = new byte[]{};
            var i = 0;
            for (; i < text.Length; i++) {
                ret = ret.Concat(FileReader.EncodeString(text[i].Replace("'", "`"))).Concat(new byte[]{0}).ToArray();
            }
            //CompiledActionData = new[]{ ActionCode, ArgX }.Concat(Uint16Bytes(ArgY)).Concat(Uint16Bytes(ArgVSpace)).Concat(new[]{ArgSize, ArgFont, (byte)i}).Concat(ret).ToArray();
            CompiledActionData = args.Concat(ret).ToArray();
            CompiledActionData[7] = (byte)i;
            CompiledActionData[0] = ArgX;
            CompiledActionData[1] = (byte) (ArgY & 0x00FF);
            CompiledActionData[2] = (byte) (ArgY >> 8);
            CompiledActionData[3] = (byte) (ArgVSpace & 0x00FF);
            CompiledActionData[4] = (byte)(ArgVSpace >> 8);
            CompiledActionData[5] = ArgSize;
            CompiledActionData[6] = ArgFont;
            CompiledActionData = new[] { ActionCode }.Concat(CompiledActionData).ToArray();

            return CompiledActionData;
        }

        public override bool HasArgChanges() {
            if (args[0] != ArgX) {
                return true;
            }
            var y = (ushort)((args[2] << 8) + args[1]);
            if (y != ArgY) {
                return true;
            }
            var vspace = (ushort)((args[4] << 8) + args[3]);
            return vspace != ArgVSpace;
        }

        public override void ResetArgs() {
            ArgX = args[0];
            ArgY = (ushort)((args[2] << 8) + args[1]);
            ArgVSpace = (ushort)((args[4] << 8) + args[3]);
        }

        public override void LoadTranslation(TranslationRow translation) {
            translation.Normalize();
            Translation = string.Join("[NL]", translation.TranslationArray);
            IsVerified = translation.IsVerified;
            LastChanged = translation.LastChanged;
            
            if (translation.ArgY > 0) {
                ArgY = translation.ArgY;
            }
            if (translation.ArgX > 0) {
                ArgX = translation.ArgX;
            }
            if (translation.ArgVSpace > 0) {
                ArgVSpace = translation.ArgVSpace;
            }
        }

        public override TranslationRow ExtractTranslation() {
            if (string.IsNullOrWhiteSpace(Translation)) return null;
            if (LastChanged.Equals(DateTime.MinValue) && !string.IsNullOrWhiteSpace(Translation)) {
                LastChanged = DateTime.Now;
            }
            var tr = new TranslationRow {
                Filename = Path.GetFileName(FileName),
                Offset = Offset,
                Code = ActionCode,
                IsVerified = IsVerified,
                OriginalArray = OriginalTextMultiline().ToList(),
                TranslationArray = Translation.Split(new[] {"[NL]"}, StringSplitOptions.None).ToList(),
                ArgX = ArgX,
                ArgY = ArgY,
                ArgVSpace = ArgVSpace,
                LastChanged = LastChanged
            };
            var exportArgs = new List<byte> {
                ArgX,
                (byte) (ArgY & 0x00FF),
                (byte) (ArgY >> 8),
                (byte) (ArgVSpace & 0x00FF),
                (byte) (ArgVSpace >> 8),
                ArgSize,
                ArgFont,
                ArgStrings
            };
            tr.Args = exportArgs;
            return tr;
        }
    }

    public class OutputText : Command
    {
        public byte TextPane { get; }
        
        private string textData;
        private string normalizedText;
        private string _translation;
        public int LineCount { get; }
        public bool IsDelimiter { get; set; }

        public OutputText(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = true;
            IsContainer = false;
            WTerminated = false;
            IsDelimiter = false;
            TextPane = reader.ReadByte();
            var text = textData = reader.ReadEstring();
            ActionData = new[]{TextPane}.Concat(FileReader.EncodeString(text)).ToArray();
            if (text.Contains(@"\WT180\") || text.Contains(@"\wt180\")) {
                text = "[W]";
                WTerminated = true;
                IsDelimiter = true;
            }
            text = text.Replace(@"\CR", "\r\n").Replace(@"\cr", "\r\n").Replace(@"\HA\CL", "").Replace(@"\ha\cl", "").Replace(@"\E", "");
            LineCount = text.Count(s => s == '\n') + 1;
            normalizedText = text;
            if (textData.EndsWith(@"\HA\CL\E") || textData.EndsWith(@"\ha\cl\e") || textData.EndsWith(@"\ha\cl\E") || (Offset == 0x007d && FileName == "SNH_C07.BIN")) {
                StringEnd = @"\HA\CL\E";
            } else {
                StringEnd = @"\E";
            }
        }

        public override string Translation {
            get {
                return _translation;
            }
            set {
                _translation = value;
                if (IsContainer && NestedCommands.Count > 0) {
                    NestedCommands[0].Translation = value;
                }
            }
        }

        public override string ToString() {
            if (IsContainer) {
                return NestedCommands.Aggregate("",
                    (agg, cmd) => (agg.Length > 0 ? agg + " | " + cmd.ToString() : cmd.ToString()));
            }
            return $"[{Offset:X4}] ({TextPane:X2})\t{normalizedText} {StringEnd}";
        }

        public override string ToString(bool original) {
            return $"[{Offset:X4}]\t{textData}";
        }

        public override string Text() {
            if (IsContainer) {
                return NestedCommands.Aggregate("", (agg, cmd) => (
                cmd.Text() == "[W]"
                    ? agg
                    : agg.Length > 0 
                        ? agg + "\r\n[BR]\r\n" + cmd.Text() 
                        : cmd.Text()
                ));
            }
            return normalizedText;
        }

        public override string OriginalText() {
            if (IsContainer) {
                return NestedCommands.Aggregate("", (agg, cmd) => (agg.Length > 0 ? agg + "\r\n[BR]\r\n" + cmd.OriginalText() : cmd.OriginalText()));
            }
            return textData;
        }

        public override byte[] Compile() {
            var text = Translation;
            if (IsContainer) {
                var result = new List<byte>();
                if (string.IsNullOrEmpty(text)) {
                    foreach (var command in NestedCommands) {
                        var item = (OutputText) command;
                        result.AddRange(item.Compile());
                    }
                } else {
                    var outMessages = SplitMessages(text);
                    foreach (var msg in outMessages) {
                        result.AddRange(CompileMessage(msg));
                        if (WTerminated) {
                            result.AddRange(CreateDelimiter());
                        }
                    }
                }
                CompiledActionData = result.ToArray();
            } else {
                if (string.IsNullOrEmpty(text) || normalizedText == "[W]") {
                    CompiledActionData = new[] {ActionCode}.Concat(ActionData).ToArray();
                } else {
                    var result = new List<byte>();
                    var outMessages = SplitMessages(text);
                    foreach (var msg in outMessages) {
                        result.AddRange(CompileMessage(msg));
                        if (WTerminated) {
                            result.AddRange(CreateDelimiter());
                        }
                    }
                    CompiledActionData = result.ToArray();
                }
            }
            return CompiledActionData;
        }

        private IEnumerable<byte> CreateDelimiter() {
            return new List<byte> { 0x18, 0x02, 0x5C, 0x57, 0x54, 0x31, 0x38, 0x30, 0x5C, 0x81, 0x40, 0x5C, 0x57, 0x54, 0x32, 0x5C, 0x5C, 0x43, 0x4C, 0x5C, 0x45 };
            //return @"\WT180\　›\WT2\\CL\E";
        }

        private IEnumerable<byte> CompileMessage(string msg) {
            msg = msg.Trim().Replace("\r\n", @"\CR").Replace("\n", @"\CR").Replace("[W]", @"\WT180").Replace("'", "`") + StringEnd;
            var data = new List<byte> {ActionCode, TextPane};
            data.AddRange(FileReader.EncodeString(msg));
            return data;
        }

        public IEnumerable<string> SplitMessages(string text) {
            var messages = text.Split(new[] {"[BR]", "[br]", "[bR]", "[Br]"}, StringSplitOptions.RemoveEmptyEntries);
            var out_messages = Enumerable.Empty<string>();
            foreach (var msg in messages) {
                out_messages = out_messages.Concat(SplitMessage(msg));
            }
            return out_messages;
        }

        private IEnumerable<string> SplitMessage(string msg) {
            var lines = Enumerable.Empty<string>();
            foreach (var line in msg.Split(new[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries)) {
                lines = lines.Concat(SplitLine(line));
            }
            var maxLineCount = NestedCommands.Aggregate(0,
                (s, cmd) => (s > (cmd as OutputText).LineCount ? s : (cmd as OutputText).LineCount));
            var messages = new List<string>();
            var cmsg = new List<string>();
            if (maxLineCount == 0) {
                maxLineCount = 2;
            }
            for (var i = 0; i < lines.Count(); i++) {
                if (i > 0 && i % maxLineCount == 0) {
                    messages.Add(cmsg.Aggregate("", (agg, m) => (agg.Length > 0 ? agg + @"\CR" + m : m)));
                    cmsg = new List<string>();
                }
                cmsg.Add(lines.ElementAt(i));
            }
            messages.Add(cmsg.Aggregate("", (agg, m) => (agg.Length > 0 ? agg + @"\CR" + m : m)));
            return messages;
        }

        private IEnumerable<string> SplitLine(string line) {
            var words = line.Split(new[] {' '}, StringSplitOptions.RemoveEmptyEntries);
            var lines = new List<string>();
            var tmpline = "";
            foreach (var word in words) {
                var len = tmpline.Length == 0 ? word.Length : word.Length + tmpline.Length + 1;
                if (len > 50) {
                    lines.Add(tmpline);
                    tmpline = word;
                } else {
                    tmpline = tmpline.Length == 0 ? word : tmpline + " " + word;
                }
            }
            lines.Add(tmpline);
            return lines;
        }

        public override bool IsSimilar(Command cmd) {
            if (cmd.GetType() != GetType()) return false;
            var cmd1 = (OutputText)cmd;
            return TextPane == cmd1.TextPane && StringEnd == cmd1.StringEnd;
        }

        public override void Append(Command cmd) {
            if (cmd.GetType() != GetType()) {
                return;
            }
            var cmd1 = (OutputText)cmd;
            if (IsContainer) {
                base.Append(cmd1);
            } else {
                base.Append(MemberwiseClone() as Command);
                IsContainer = true;
                base.Append(cmd1);
            }
            StringEnd = cmd1.StringEnd;
            normalizedText = normalizedText + "\r\n" + cmd1.Text();
            Translation = Translation + "\r\n" + cmd1.Translation;
            if (cmd1.WTerminated) {
                WTerminated = true;
            }
        }

        public bool WTerminated { get; set; }

        public override void LoadTranslation(TranslationRow translation) {
            Translation = translation.Translation;
            IsVerified = translation.IsVerified;
            LastChanged = translation.LastChanged;
            /*if (!string.IsNullOrWhiteSpace(translation.StringEnd)) {
                StringEnd = translation.StringEnd;
            }*/
        }

        public void AppendTranslation(TranslationRow translation) {
            if (!string.IsNullOrEmpty(Translation) &&
                !string.IsNullOrEmpty(translation.Translation)) {
                Debug.WriteLine("Append to container (non empty)");
                translation.Normalize();
                Translation = Translation + "\r\n[BR]\r\n" + translation.Translation;
            } else if (string.IsNullOrEmpty(Translation) &&
                       !string.IsNullOrEmpty(translation.Translation)) {
                Debug.WriteLine("Append to empty container");
                translation.Normalize();
                Translation = translation.Translation;
            } else {
                Debug.WriteLine("Can't add///");
            }
        }

        public override TranslationRow ExtractTranslation() {
            if (string.IsNullOrWhiteSpace(Translation)) return null;
            if (LastChanged.Equals(DateTime.MinValue) && !string.IsNullOrWhiteSpace(Translation)) {
                LastChanged = DateTime.Now;
            }
            var tr = new TranslationRow {
                Filename = Path.GetFileName(FileName),
                Offset = Offset,
                Code = ActionCode,
                IsVerified = IsVerified,
                Original = OriginalText(),
                Translation = Translation,
                LastChanged = LastChanged
            };
            if (IsDelimiter) {
                tr.IsDelimiter = true;
            }
            if (WTerminated) {
                tr.WaitTerminated = true;
            }
            if (IsContainer) {
                tr.NestedRows = new List<TranslationRow>();
                for (var i = 0; i < NestedCommands.Count; i++) {
                    var nested = NestedCommands[i] as OutputText;
                    var nested_tr = new TranslationRow() {
                        Filename = nested.FileName,
                        Offset = nested.Offset,
                        Code = nested.ActionCode,
                        Original = nested.OriginalText(),
                        StringEnd = nested.StringEnd
                    };
                    if (nested.IsDelimiter) {
                        nested_tr.IsDelimiter = true;
                    }
                    if (nested.WTerminated) {
                        nested_tr.WaitTerminated = true;
                    }
                    tr.NestedRows.Add(nested_tr);
                }
            }
            tr.StringEnd = StringEnd;
            return tr;
        }
    }
}
