﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Xml;
using System.Xml.Serialization;
using Clipboard = System.Windows.Forms.Clipboard;
using Color = System.Drawing.Color;
using KeyEventArgs = System.Windows.Forms.KeyEventArgs;
using ListBox = System.Windows.Forms.ListBox;
using MessageBox = System.Windows.Forms.MessageBox;
using Size = System.Drawing.Size;

/*
 * 
 TODO на потом: сделать так, чтобы при ShowCommands строки показывались в оригинальном виде, без вырезания командных частей

    1. Для текста - автоматическое деление на строки (по длине)
    2. В сообщении не должно быть строк больше, чем в оригинале. Если строк больше, чем в оригинале, нужно создавать следующее 18-сообщение.
    
    При отображении текста 18 склеивать идущие подряд команды с одинаковым первым параметром.
При этом на месте склейки показывать какой-либо спецсимвол.

При компиляции переразбивать по-новой, за кол-во строк в боксе брать максимальное из тех, что были в оригинале.
Дать возможность по спецсимволу принудительно разбивать на мессаджбоксы.
Переносы строк брать из перевода как есть, если строки длиннее, чем максимально допустимая длина строки, то делать принудительный перенос

КОСТЫЛЬ - апостроф (') заменяем на ` , т.к. он ломает игру (надо хакать)

    Ширина поля - 50 символов

Есть какой-то баг с \r\n => \n в переводе. Надо поискать

*/

namespace ScenarioEditor {
    public partial class TranslationForm : Form {
        string binPath;
        string settingsPath;
        private string exportBinPath;
        private string translationPath;
        Dictionary<string, ParsedFile> parsedFiles = new Dictionary<string, ParsedFile>();
        private Timer timer;
        private bool hasUnsavedChanges = false;
        System.Windows.Controls.TextBox tbTranslation1 = new System.Windows.Controls.TextBox();

        public TranslationForm() {
            InitializeComponent();
            lbStrings.DrawMode = DrawMode.OwnerDrawFixed;
            ;
            lbFiles.DrawMode = DrawMode.OwnerDrawFixed;
        }

        private void TranslationForm_Load(object sender, EventArgs e) {
            timer = new Timer {Interval = 60000};
            timer.Tick += TimerOnTick;
            timer.Enabled = true;
            pLoading.Hide();
            tbTranslation1.SpellCheck.IsEnabled = true;
            tbTranslation1.Language = System.Windows.Markup.XmlLanguage.GetLanguage("en-US");
            elementHost1.Child = tbTranslation1;
            tbTranslation1.FontFamily = new System.Windows.Media.FontFamily("Consolas");
            tbTranslation1.TextWrapping = TextWrapping.Wrap;
            tbTranslation1.AcceptsReturn = true;
            tbTranslation1.VerticalScrollBarVisibility = ScrollBarVisibility.Auto;
            tbTranslation1.KeyUp += TbTranslation1_KeyUp;
            tbTranslation1.KeyDown += TbTranslation1_KeyDown;
            HideTextHandlers();
            //= new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
        }

        private void TbTranslation1_KeyDown(object sender, System.Windows.Input.KeyEventArgs e) {
            if ((e.KeyboardDevice.IsKeyDown(Key.LeftCtrl) || e.KeyboardDevice.IsKeyDown(Key.RightCtrl)) && e.Key == Key.A) {
                tbTranslation1.SelectAll();
                e.Handled = true;
            } else if ((e.KeyboardDevice.IsKeyDown(Key.LeftCtrl) || e.KeyboardDevice.IsKeyDown(Key.RightCtrl)) &&
                       e.Key == Key.S) {
                SaveTranslationFile();
                e.Handled = true;
            } else if ((e.KeyboardDevice.IsKeyDown(Key.LeftCtrl) || e.KeyboardDevice.IsKeyDown(Key.RightCtrl)) &&
                       e.KeyboardDevice.IsKeyDown(Key.Down)) {
                if (lbStrings.SelectedIndex < (lbStrings.Items.Count - 1)) {
                    lbStrings.SelectedIndex++;
                    Refresh();
                    if (tabTranslationPane.SelectedIndex == 0) {
                        tbTranslation1.Focus();
                    } else {
                        dgTranslation.Focus();
                    }
                }
                e.Handled = true;
            } else if ((e.KeyboardDevice.IsKeyDown(Key.LeftCtrl) || e.KeyboardDevice.IsKeyDown(Key.RightCtrl)) &&
                       e.KeyboardDevice.IsKeyDown(Key.Up)) {
                if (lbStrings.SelectedIndex > 0) {
                    lbStrings.SelectedIndex--;
                    Refresh();
                    if (tabTranslationPane.SelectedIndex == 0) {
                        tbTranslation1.Focus();
                    } else {
                        dgTranslation.Focus();
                    }
                }
                e.Handled = true;
            }
        }

        private void TbTranslation1_KeyUp(object sender, System.Windows.Input.KeyEventArgs e) {
            var selected = lbStrings.SelectedItem;
            if (selected != null) {
                LoadPreview(selected as Command, tbTranslation1.Text);
                if ((selected as Command).Translation != tbTranslation1.Text) {
                    hasUnsavedChanges = true;
                    tsChanged.Text = "Changed";
                }
            }
        }

        private void TranslationForm_Shown(object sender, EventArgs e) {
            tabTranslationPane.ItemSize = new Size(0, 1);
            tabTranslationPane.Hide();
            cbTranslationIsVerified.Hide();
            HideTextHandlers();
            var user_dir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            settingsPath = Path.Combine(user_dir, "macross_translation.txt");
            tsChanged.Text = "";
            if (File.Exists(settingsPath)) {
                var strings = File.ReadAllLines(settingsPath);
                bOpenDir.ToolTipText = "Open directory (" + strings[0] + ")";
                if (strings.Length > 1) {
                    translationPath = strings[1];
                    bOpenTranslation.ToolTipText = "Load translation file (" + translationPath + ")";
                }
                if (strings.Length > 2) {
                    exportBinPath = strings[2];
                    bCompile.ToolTipText = "Compile BINs (SHIFT + click to select another directory) (" + exportBinPath +
                                       ")";
                }
                LoadFiles(strings[0]);
            }
        }

        private void TimerOnTick(object sender, EventArgs eventArgs) {
            if (string.IsNullOrEmpty(translationPath)) return;
            var path = translationPath.Replace(".xml", ".save.xml");
            SaveTranslationFile(path);
        }

        private void LoadFiles(string s) {
            if (!Directory.Exists(s)) return;
            binPath = s;
            bOpenDir.ToolTipText = "Open directory (" + binPath + ")";
            var files = Directory.GetFiles(binPath);
            pLoading.Show();
            this.Refresh();
            lbFiles.Items.Clear();
            parsedFiles.Clear();
            foreach (var file in files) {
                var filename = file.Replace(binPath + "\\", "");
                if (filename.StartsWith("TAC") || filename.EndsWith("MES.BIN") || filename == "MAC_DATA.BIN")
                    continue;
                lbFiles.Items.Add(filename);
                this.Refresh();
                parsedFiles.Add(filename, FileParser.Parse(Path.Combine(binPath, filename)));
            }
            if (!string.IsNullOrEmpty(translationPath)) {
                LoadTranslation(translationPath, false);
            }
            pLoading.Hide();
            this.Refresh();
        }

        private void bOpenDir_Click(object sender, EventArgs e) {
            var browser = new FolderBrowserDialog {Description = "Open folder containing BIN files"};
            if (browser.ShowDialog() == DialogResult.OK) {
                if (binPath == browser.SelectedPath) return;
                LoadFiles(browser.SelectedPath);
            }
        }

        private void TranslationForm_FormClosing(object sender, FormClosingEventArgs e) {
            if (hasUnsavedChanges) {
                var result = MessageBox.Show("You have unsaved changes. Save before exit?", "Save before close",
                    MessageBoxButtons.YesNoCancel,
                    MessageBoxIcon.Question);
                if (result == DialogResult.Cancel) {
                    e.Cancel = true;
                    return;
                }
                if (result == DialogResult.Yes) {
                    SaveTranslationFile();
                }
            } else {
                var result = MessageBox.Show("Are you sure that you would like to exit editor?", "Confirm closing",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);
                if (result == DialogResult.No) {
                    e.Cancel = true;
                    return;
                }

            }
            SaveSettings();
        }

        private void SaveSettings() {
            File.WriteAllLines(settingsPath, new string[] {binPath, translationPath, exportBinPath});
        }

        private void lbFiles_SelectedIndexChanged(object sender, EventArgs e) {
            FilterStrings();
        }

        private void FilterStrings() {
            var file = (string) lbFiles.SelectedItem;
            if (file == null) return;
            SaveTranslation();
            tabTranslationPane.Hide();
            cbTranslationIsVerified.Hide();
            HideTextHandlers();
            Debug.WriteLine(file);
            if (!parsedFiles.ContainsKey(file)) {
                parsedFiles.Add(file, FileParser.Parse(Path.Combine(binPath, file)));
            }
            var parsed = parsedFiles[file];
            lbStrings.Items.Clear();
            SelectedIndex = -1;
            var total_strings = 0.0;
            var translated = 0.0;
            tsLineCount.Text = "0";
            tsTranslatedLines.Text = "0";
            tsTranslationPercent.Text = "0%";
            foreach (var item in parsed.Commands) {
                /*if (item.GetType() == typeof(SetVar)) {
                    if ((item as SetVar).VarAddr == 0x1b) {
                        lbStrings.Items.Add(item);
                    }
                }
                continue;*/
                if (bShowCommands.Checked) {
                    if (item.IsContainer) {
                        foreach (var subitem in item.NestedCommands) {
                            lbStrings.Items.Add(subitem);
                        }
                    } else {
                        lbStrings.Items.Add(item);
                    }
                } else {
                    if ((item.IsText && item.Text() != "[W]")) {
                        total_strings++;
                        if (!string.IsNullOrWhiteSpace(item.Translation)) {
                            translated++;
                        }
                        lbStrings.Items.Add(item);
                    }
                }
            }
            tsLineCount.Text = total_strings.ToString();
            tsTranslatedLines.Text = translated.ToString();
            if (translated > 0 && total_strings > 0) {
                //toolStripStatusLabel3.Text = string.Format("{0:D}%", (int)((translated / total_strings) * 100));
                tsTranslationPercent.Text = string.Format("{0:D}%", (int)((translated / total_strings) * 100));
            }
            if (parsed.FullyTranslated) {
                tsTranslationPercent.Text = "100%";
            }
        }

        private void bShowCommands_Click(object sender, EventArgs e) {
            FilterStrings();
        }

        private void lbStrings_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyCode == Keys.C && e.Modifiers == Keys.Control) {
                var s = (Command) lbStrings.SelectedItem;
                if (s != null) {
                    Clipboard.SetText(s.Text());
                }
            }
        }


        private string SaveTranslation() {
            if (SelectedIndex <= -1) return null;
            

            var previous = (Command) lbStrings.Items[SelectedIndex];

            if (!previous.IsText) {
                SaveCommand(previous);
                return "";
            }
            if (bShowCommands.Checked) return null;
            var old_translation = previous.Translation;

            if (previous.IsMultiline) {
                var orig = previous.Text().Split(new[] {"[NL]"}, StringSplitOptions.None);
                var str = "";
                var src = dgTranslation.DataSource as List<TranslationDataRow>;
                if (src == null) return null;

                var not_empty = src.Any(t => !string.IsNullOrEmpty(t.Translation));
                if (!not_empty) return null;

                for (var i = 0; i < src.Count; i++) {
                    var row = src[i];
                    Debug.WriteLine(row.GetType());
                    var translation = row.Translation;
                    if (string.IsNullOrEmpty(translation)) {
                        if (orig.Length > i) {
                            translation = orig[i];
                        }
                    }
                    if (i == 0) {
                        str = translation;
                    } else {
                        str = str + "[NL]" + translation;
                    }
                }
                var cmd = previous as OutputString;
                cmd.ArgX = (byte)nudX.Value;
                cmd.ArgY = (ushort) nudY.Value;
                cmd.ArgVSpace = (ushort) nudVerticalSpace.Value;
                if (previous.Translation == str) {
                    previous.IsVerified = cbTranslationIsVerified.Checked;
                    return null;
                }
                previous.IsVerified = false;
                previous.Translation = str;
                previous.LastChanged = DateTime.Now;
            } else {
                if (string.IsNullOrWhiteSpace(tbTranslation1.Text)) {
                    return null;
                }
                if (tbTranslation1.Text == previous.Translation) {
                    previous.IsVerified = cbTranslationIsVerified.Checked;
                    return null;
                }
                previous.IsVerified = false;
                previous.Translation = tbTranslation1.Text;
                previous.LastChanged = DateTime.Now;
            }
            var filename = Path.GetFileName(previous.FileName);
            if (parsedFiles.ContainsKey(filename)) {
                var file = parsedFiles[filename];
                if (tbTranslateRepeated.Checked) {
                    foreach (var cmd in file.Commands) {
                        if (cmd.IsText && cmd.Text() == previous.Text() && cmd.Translation == old_translation &&
                            cmd.Offset != previous.Offset) {
                            cmd.Translation = previous.Translation;
                        }
                    }
                }
            }
            lbFiles.Refresh();
            lbStrings.Refresh();
            hasUnsavedChanges = true;
            tsChanged.Text = "Changed";
            return old_translation;
        }

        private void SaveCommand(Command cmd) {
            var type = cmd.GetType();
            if (type == typeof(InitScreenRegion)) {
                var a1 = (byte)nud11_1.Value;
                var a2 = (ushort) nud11_2.Value;
                var a3 = (byte) nud11_3.Value;
                var a4 = (ushort) nud11_4.Value;
                var a5 = (ushort) nud11_5.Value;
                var a6 = (byte) nud11_6.Value;
                var cmd1 = cmd as InitScreenRegion;
                if (cmd1.Arg1 != a1 || cmd1.Arg2 != a2 || cmd1.Arg3 != a3 || cmd1.Arg4 != a4 || cmd1.Arg5 != a5 ||
                    cmd1.Arg6 != a6) {
                    cmd1.Arg1 = a1;
                    cmd1.Arg2 = a2;
                    cmd1.Arg3 = a3;
                    cmd1.Arg4 = a4;
                    cmd1.Arg5 = a5;
                    cmd1.Arg6 = a6;
                }
            }
        }

        private int SelectedIndex = -1;
        private bool changeTab = false;

        private void lbStrings_SelectedIndexChanged(object sender, EventArgs e) {
            SaveTranslation();
            LoadTranslationToPanel();
            lbStrings.Refresh();
        }

        private string currentOriginal = "";
        private string currentTranslation = "";

        private void LoadTranslationToPanel() {
            tsCommandArgs.Text = "";
            var s = lbStrings.SelectedItem;
            if (s == null) return;
            Command selected;
            lbStrings.Focus();
            if (lbStrings.SelectedItem != null) {
                selected = (Command)lbStrings.SelectedItem;
                SelectedIndex = lbStrings.SelectedIndex;
            } else {
                SelectedIndex = -1;
                return;
            }
            
            if (bShowCommands.Checked) {
                if (lbStrings.SelectedItem != null) {
                    selected = (Command) lbStrings.SelectedItem;
                    tsCommandArgs.Text = selected.StrArgs();
                    if (!selected.IsText) {
                        ShowCommandEditor(selected);
                    } else {
                        tabTranslationPane.Hide();
                    }
                }
                return;
            }

            if (!selected.IsText) return;
            currentOriginal = selected.Text();
            currentTranslation = selected.Translation;
            if (selected.IsMultiline) {
                var strings = selected.Text().Split(new string[] {"[NL]"}, StringSplitOptions.None);
                var translations = selected.Translation.Split(new string[] {"[NL]"}, StringSplitOptions.None);
                if (translations.Length != strings.Length) {
                    translations = new string[strings.Length];
                    for (var i = 0; i < strings.Length; i++) {
                        translations[i] = "";
                    }
                }
                //var src = new BindingSource();
                var src = new List<TranslationDataRow>();
                for (var i = 0; i < strings.Length; i++) {
                    var row = new TranslationDataRow();
                    row.Original = strings[i];
                    Debug.WriteLine(strings[i]);
                    row.Translation = row.OldTranslation = translations[i];
                    Debug.WriteLine(translations[i]);
                    src.Add(row);
                }
                dgTranslation.DataSource = src;
                dgTranslation.Refresh();
                dgTranslation.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
                if (tabTranslationPane.SelectedIndex != 1) {
                    changeTab = true;
                    tabTranslationPane.SelectedIndex = 1;
                }
                ShowTextHandlers(selected as OutputString);
            } else {
                tbOriginalText.Text = selected.Text();
                tbTranslation1.Text = selected.Translation;
                if (tabTranslationPane.SelectedIndex != 0) {
                    changeTab = true;
                    tabTranslationPane.SelectedIndex = 0;
                }
                LoadPreview(selected, selected.Translation);
                HideTextHandlers();
            }
            cbTranslationIsVerified.Show();
            cbTranslationIsVerified.Checked = selected.IsVerified;
            tabTranslationPane.Show();
            lbStrings.Focus();
        }

        private void ShowCommandEditor(Command cmd) {
            var type = cmd.GetType();
            if (type == typeof(InitScreenRegion)) {
                tabTranslationPane.Show();
                tpInitScreenRegion.Show();
                if (tabTranslationPane.SelectedIndex != tpInitScreenRegion.TabIndex) {
                    changeTab = true;
                    tabTranslationPane.SelectedIndex = tpInitScreenRegion.TabIndex;
                }
                var cmd1 = cmd as InitScreenRegion;
                nud11_1.Value = cmd1.Arg1;
                nud11_2.Value = cmd1.Arg2;
                nud11_3.Value = cmd1.Arg3;
                nud11_4.Value = cmd1.Arg4;
                nud11_5.Value = cmd1.Arg5;
                nud11_6.Value = cmd1.Arg6;
            } else {
                tabTranslationPane.Hide();
            }
        }

        private void LoadPreview(Command selected, string translation) {
            if (!string.IsNullOrWhiteSpace(translation)) {
                var cmdtext = selected as OutputText;
                var preview = cmdtext.SplitMessages(translation);
                var previewstr = preview.Select(str => str.Replace(@"\CR", "\r\n"))
                    .Aggregate("", (agg, str) => (agg == "" ? str : agg + "\r\n---------------------\r\n" + str));
                tbPreview.Text = previewstr;
            } else {
                tbPreview.Text = "";
            }
        }

        private void bSaveTranslation_Click(object sender, EventArgs e) {
            lbStrings.Focus();
            if ((ModifierKeys & Keys.Shift) != 0) {
                if (!ChooseSaveFile()) return;
            }
            SaveTranslationFile();
        }

        private void TranslationForm_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyCode == Keys.S && e.Modifiers == Keys.Control) {
                SaveTranslationFile();
            } else if (e.KeyCode == Keys.F3) {
                Debug.WriteLine("Search Next " + searchString);
                SearchNext();
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData) {
            Debug.WriteLine("{0}", keyData);
            if (keyData == Keys.F3) {
                Debug.WriteLine("Search Next " + searchString);
                SearchNext();
                return true; // indicate that you handled this keystroke
            } else if (keyData == (Keys.Control | Keys.Down) || keyData == (Keys.Control | Keys.Down | Keys.Alt)) {
                if (lbStrings.SelectedIndex < (lbStrings.Items.Count - 1)) {
                    lbStrings.SelectedIndex++;
                    Refresh();
                    if (tabTranslationPane.SelectedIndex == 0) {
                        tbTranslation1.Focus();
                    } else {
                        dgTranslation.Focus();
                    }
                }
                return true;
            } else if (keyData == (Keys.Control | Keys.Up) || keyData == (Keys.Control | Keys.Up | Keys.Alt)) {
                if (lbStrings.SelectedIndex > 0) {
                    lbStrings.SelectedIndex--;
                    Refresh();
                    if (tabTranslationPane.SelectedIndex == 0) {
                        tbTranslation1.Focus();
                    } else {
                        dgTranslation.Focus();
                    }
                }
                return true;
            }

            // Call the base class
                return base.ProcessCmdKey(ref msg, keyData);
        }

        private void SaveTranslationFile() {
            if (string.IsNullOrEmpty(translationPath)) {
                if (!ChooseSaveFile()) return;
            }
            SaveTranslationFile(translationPath);
        }

        private bool ChooseSaveFile() {
            var dialog = new SaveFileDialog();
            dialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
            dialog.FilterIndex = 0;
            dialog.DefaultExt = "xml";
            if (dialog.ShowDialog() == DialogResult.OK) {
                translationPath = dialog.FileName;
                Debug.WriteLine(translationPath);
                return true;
            } else {
                return false;
            }
        }

        private void SaveTranslationFile(string savePath) {
            SaveTranslation();

            var translations = new List<TranslationRow>();
            foreach (var file in parsedFiles.Values) {
                foreach (var cmd in file.Commands) {
                    var tr = cmd.ExtractTranslation();
                    if (tr != null) {
                        translations.Add(tr);
                    }
                }
            }
            XmlSerializer ser = new XmlSerializer(typeof(Translation));

            if (File.Exists(savePath)) {
                File.Delete(savePath);
            }
            using (var fs = new FileStream(savePath, FileMode.OpenOrCreate)) {
                Debug.WriteLine("Save to " + savePath);
                ser.Serialize(fs, new Translation { Translations = translations });
            }
            hasUnsavedChanges = false;
            tsChanged.Text = "";
        }

        private void LoadTranslation(string trPath, bool checkDate) {
            if (!File.Exists(trPath)) return;
            XmlSerializer ser = new XmlSerializer(typeof(Translation));

            using (FileStream fs = new FileStream(trPath, FileMode.OpenOrCreate)) {
                XmlReaderSettings settings = new XmlReaderSettings {CheckCharacters = false};
                // default value is true;
                XmlReader xr3 = XmlTextReader.Create(fs, settings);
                    // xr3.Settings.CheckCharacters is a read only and xr3's type is XmlTextReaderImpl

                try {
                    var tr_obj = (Translation) ser.Deserialize(xr3);
                    for (var tr_i = 0; tr_i < tr_obj.Translations.Count; tr_i++) {
                        var translation = tr_obj.Translations[tr_i];
                        translation.Normalize();
                        
                        if (!parsedFiles.ContainsKey(translation.Filename)) {
                            parsedFiles.Add(translation.Filename, FileParser.Parse(Path.Combine(binPath, translation.Filename)));
                        }
                        Debug.WriteLine("Read translation " + translation.Translation);
                        var file = parsedFiles[translation.Filename];
                        file.TryLoadTranslation(translation, checkDate);
                    }
                } catch (Exception e) {
                    Debug.WriteLine(e);
                    MessageBox.Show("Error", "Can't load XML file");
                }
                foreach (var file in parsedFiles.Values) {
                    file.CheckTranslationStatus();
                }
                lbFiles.Refresh();
            }
        }

        private void tabTranslationPane_Selecting(object sender, TabControlCancelEventArgs e) {
            if (!changeTab) {
                e.Cancel = true;
            } else {
                changeTab = false;
            }
        }

        private void bOpenTranslation_Click(object sender, EventArgs e) {
            var dialog = new OpenFileDialog {
                Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*",
                FilterIndex = 0,
                DefaultExt = "xml"
            };
            if (dialog.ShowDialog() == DialogResult.OK) {
                if (translationPath == dialog.FileName) {
                    return;
                }
                translationPath = dialog.FileName;
                bOpenTranslation.ToolTipText = "Load translation file (" + translationPath + ")";
                Debug.WriteLine(translationPath);
                LoadTranslation(translationPath, false);
            } else {
                return;
            }
        }

        #region search
        private string searchString;
        private int searchFileIndex = 0;
        private int searchCmdIndex = 0;
        private int listIndex = 0;

        private void tbSearch_KeyDown(object sender, KeyEventArgs e) {
            if (e.KeyCode == Keys.Enter) {
                searchString = tbSearch.Text;
                searchFileIndex = 0;
                searchCmdIndex = 0;
                listIndex = 0;
                SearchNext();
            } else if (e.KeyCode == Keys.F3) {
                Debug.WriteLine("Search Next " + searchString);
                SearchNext();
            }
        }

        private void SearchNext() {
            if (string.IsNullOrEmpty(searchString)) {
                searchString = tbSearch.Text;
            }
            for (; searchFileIndex < lbFiles.Items.Count; searchFileIndex++) {
                var file = (string) lbFiles.Items[searchFileIndex];
                if (!parsedFiles.ContainsKey(file)) {
                    parsedFiles.Add(file, FileParser.Parse(Path.Combine(binPath, file)));
                }
                var parsed = parsedFiles[file];
                for (; searchCmdIndex < parsed.Commands.Length; searchCmdIndex++) {
                    if (parsed.Commands[searchCmdIndex].IsText) {
                        listIndex++;
                        if (parsed.Commands[searchCmdIndex].Text().Contains(searchString) || parsed.Commands[searchCmdIndex].Translation.Contains(searchString)) {
                            Debug.WriteLine("command text: ", parsed.Commands[searchCmdIndex].Text());
                            Debug.WriteLine("Search text: " + searchString);
                            lbFiles.SelectedIndex = searchFileIndex;
                            FilterStrings();
                            lbStrings.SelectedIndex = listIndex - 1;
                            LoadTranslationToPanel();
                            searchCmdIndex++;
                            return;
                        }
                    } else {
                        if (bShowCommands.Checked) {
                            listIndex++;
                        }
                    }
                }
                searchCmdIndex = 0;
                listIndex = 0;
            }
            searchFileIndex = 0;
        }

        private void tbSearch_Click(object sender, EventArgs e) {
            tbSearch.SelectAll();
        }
        #endregion
        private void lbStrings_DoubleClick(object sender, EventArgs e) {
            var s = (Command) lbStrings.SelectedItem;
            if (s != null) {
                Clipboard.SetText(s.Text());
            }
        }

        private void tbOriginalText_DoubleClick(object sender, EventArgs e) {
            Clipboard.SetText(tbOriginalText.Text);
        }

        private void tbCopyText_Click(object sender, EventArgs e) {
            lbStrings.Focus();
            var s = (Command) lbStrings.SelectedItem;
            if (s != null) {
                Clipboard.SetText(s.Text());
            }
        }

        private void lbStrings_DrawItem(object sender, DrawItemEventArgs e) {
            e.DrawBackground();
            Graphics g = e.Graphics;
            ListBox lb = (ListBox) sender;

            // draw the background color you want
            // mine is set to olive, change it to whatever you want
            if (e.Index > -1) {
                var item = (Command) lb.Items[e.Index];
                if (tbTranslateRepeated.Checked && (e.State & DrawItemState.Selected) == 0 &&
                    item.Text() == currentOriginal &&
                    item.Translation == currentTranslation) {
                    g.FillRectangle(new SolidBrush(Color.Wheat), e.Bounds);
                } else if ((e.State & DrawItemState.Selected) != 0) {
                    g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);
                } else if (String.IsNullOrEmpty(item.Translation.Trim()) ||
                           item.Text() == item.Translation) {
                    if (item.IsContainer) {
                        g.FillRectangle(new SolidBrush(Color.LightYellow), e.Bounds);
                    } else {
                        g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);
                    }
                } else {
                    if (item.IsContainer) {
                        if (item.IsVerified) {
                            g.FillRectangle(new SolidBrush(Color.LightGreen), e.Bounds);
                        } else {
                            g.FillRectangle(new SolidBrush(Color.Aquamarine), e.Bounds);
                        }
                    } else {
                        if (item.IsVerified) {
                            g.FillRectangle(new SolidBrush(Color.DeepSkyBlue), e.Bounds);
                        } else {
                            g.FillRectangle(new SolidBrush(Color.Aqua), e.Bounds);
                        }
                    }
                }

                // draw the text of the list item, not doing this will only show
                // the background color
                // you will need to get the text of item to display
                g.DrawString(item.ToString().Replace("\r\n", " "), e.Font, new SolidBrush(e.ForeColor),
                    new PointF(e.Bounds.X, e.Bounds.Y));
            } else {
                g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);
            }

            e.DrawFocusRectangle();
        }

        private void lbFiles_DrawItem(object sender, DrawItemEventArgs e) {
            e.DrawBackground();
            Graphics g = e.Graphics;
            ListBox lb = (ListBox) sender;
            if (e.Index > -1) {
                var item = (string) lb.Items[e.Index];
                ParsedFile file = null;
                if (parsedFiles.ContainsKey(item)) {
                    file = parsedFiles[item];
                }
                if ((e.State & DrawItemState.Selected) == 0 && file != null && file.IsEmpty()) {
                    g.FillRectangle(new SolidBrush(Color.SlateGray), e.Bounds);
                } else if ((e.State & DrawItemState.Selected) != 0 || file == null || !file.FullyTranslated) {
                    g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);
                } else {
                    g.FillRectangle(new SolidBrush(Color.Aquamarine), e.Bounds);
                }
                g.DrawString(item.ToString().Replace("\r\n", " "), e.Font, new SolidBrush(e.ForeColor),
                    new PointF(e.Bounds.X, e.Bounds.Y));
            } else {
                g.FillRectangle(new SolidBrush(e.BackColor), e.Bounds);
            }

            e.DrawFocusRectangle();
        }


        private void tbTranslateAllFiles_Click(object sender, EventArgs e) {
            if (SelectedIndex > -1) {
                lbStrings.Focus();
                var previous = (Command) lbStrings.Items[SelectedIndex];
                var old_translation = previous.Translation;
                SaveTranslation();
                pLoading.Show();
                this.Refresh();
                Debug.WriteLine("Copy translation " + previous.Translation + " to all files with " + old_translation +
                                " translation");
                foreach (string f in lbFiles.Items) {
                    if (!parsedFiles.ContainsKey(f)) {
                        parsedFiles.Add(f, FileParser.Parse(Path.Combine(binPath, f)));
                    }
                    var parsed_file = parsedFiles[f];
                    foreach (var cmd in parsed_file.Commands) {
                        if (cmd.IsText && cmd.Text() == previous.Text()) { 
                        /*if (cmd.IsText && cmd.Text() == previous.Text() &&
                            (cmd.Translation == old_translation || cmd.Translation == "")) {*/
                            cmd.Translation = previous.Translation;
                        }
                    }
                    parsed_file.CheckTranslationStatus();
                }
                pLoading.Hide();
                this.Refresh();
            }
        }

        private void mCopyOriginal_Click(object sender, EventArgs e) {
            lbStrings.Focus();
            var s = (Command) lbStrings.SelectedItem;
            if (s != null) {
                Clipboard.SetText(s.Text());
            }
        }

        private bool ChooseExportFolder() {
            var browser = new FolderBrowserDialog {Description = "Open folder containing BIN files"};
            if (browser.ShowDialog() == DialogResult.OK) {
                exportBinPath = browser.SelectedPath;
                bCompile.ToolTipText = "Compile BINs (SHIFT + click to select another directory) (" + exportBinPath +
                                       ")";
                return true;
            }
            return false;
        }

        private void bCompile_Click(object sender, EventArgs e) {
            lbStrings.Focus();
            if ((ModifierKeys & Keys.Shift) != 0 || string.IsNullOrEmpty(exportBinPath)) {
                if (!ChooseExportFolder()) return;
            }
            if (!Directory.Exists(exportBinPath)) {
                MessageBox.Show("Error", "Can't export BIN files to unexisting folder!");
                return;
            }
            pLoading.Show();
            foreach (var f in parsedFiles.Values) {
                try {
                    Debug.WriteLine("Compile " + f.FileName);
                    f.Compile(exportBinPath);
                } catch (Exception ex) {
                    MessageBox.Show("Can't compile file " + f.FileName, ex.ToString());
                }
            }
            pLoading.Hide();
        }

        private void HideTextHandlers() {
            lFont.Hide();
            lSize.Hide();
            lLeft.Hide();
            lY.Hide();
            lVspace.Hide();
            lStringCount.Hide();
            nudFont.Hide();
            nudSize.Hide();
            nudStringCount.Hide();
            nudVerticalSpace.Hide();
            nudX.Hide();
            nudY.Hide();
            bReset.Hide();
        }

        private void ShowTextHandlers(OutputString cmd) {
            lFont.Show();
            lSize.Show();
            lLeft.Show();
            lY.Show();
            lVspace.Show();
            lStringCount.Show();
            nudFont.Show();
            nudFont.Value = cmd.ArgFont;
            nudSize.Show();
            nudSize.Value = cmd.ArgSize;
            nudStringCount.Show();
            nudStringCount.Value = cmd.ArgStrings;
            nudVerticalSpace.Show();
            nudVerticalSpace.Value = cmd.ArgVSpace;
            nudX.Show();
            nudX.Value = cmd.ArgX;
            nudY.Show();
            nudY.Value = cmd.ArgY;
            if (cmd.HasArgChanges()) {
                bReset.Show();
            } else {
                bReset.Hide();
            }
        }

        private void bReset_Click(object sender, EventArgs e) {
            var cmd = lbStrings.SelectedItem as OutputString;
            if (cmd == null) return;
            cmd.ResetArgs();
            ShowTextHandlers(cmd);
        }

        private void b11_reset_Click(object sender, EventArgs e) {
            var cmd = lbStrings.SelectedItem as InitScreenRegion;
            if (cmd == null) return;
            cmd.ResetArgs();
            ShowCommandEditor(cmd);
        }

        private void bImport_Click(object sender, EventArgs e) {
            var dialog = new OpenFileDialog {
                Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*",
                FilterIndex = 0,
                DefaultExt = "xml"
            };
            if (dialog.ShowDialog() == DialogResult.OK) {
                LoadTranslation(dialog.FileName, true);
            }
        }
    }
}