﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;
using System.Threading.Tasks;

namespace ScenarioEditor
{
    public class ExitKey : Command
    {
        public ExitKey(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
        }
        public override string ToString() {
            return $"[{Offset:X4}]\tExitKey()";
        }
    }

    public class LoadOnKeyPress : Command
    {
        private ushort loadNumber;
        private byte scenePart;

        public ushort LoadNumber { get; set; }
        public byte ScenePart { get; set; }
        
        public LoadOnKeyPress(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            LoadNumber = loadNumber = reader.ReadUint16();
            ScenePart = scenePart = reader.ReadByte();
            ActionData = ArrayAppend(loadNumber, scenePart);
        }
        public override string ToString() {
            return $"[{Offset:X4}]\tLoadOnKeyPress(0x{loadNumber:X4}, 0x{scenePart:X2})";
        }

        public override bool HasArgChanges() {
            return LoadNumber != loadNumber || ScenePart != scenePart;
        }

        public override void ResetArgs() {
            LoadNumber = loadNumber;
            ScenePart = scenePart;
        }
    }

    public class ReadNextByte : Command
    {
        private byte arg;
        public ReadNextByte(byte cmd, FileReader reader) : base(cmd, reader) {
            arg = reader.ReadByte();
            IsText = false;
            ActionData = new[]{arg};
        }
        public override string ToString() {
            return $"[{Offset:X4}]\tReadNextByte({arg:X2})";
        }
    }

    public class TitleScreen : Command
    {
        public TitleScreen(byte cmd, FileReader reader) : base(cmd, reader) {

            IsText = false;
        }
        public override string ToString() {
            return $"[{Offset:X4}]\tTitmeScreen()";
        }
    }



    public class EventCheck : Command
    {
        public EventCheck(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
        }
        public override string ToString() {
            return $"[{Offset:X4}]\tEventCheck()";
        }
    }

    public class MakeAnimation : Command
    {
        private ushort loadNumber;
        private byte[] unknownArgs;
        private byte lineCount;
        private byte[][] animationData;
        public MakeAnimation(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            loadNumber = reader.ReadUint16();
            unknownArgs = reader.ReadBytes(3);
            lineCount = reader.ReadByte();
            animationData = new byte[lineCount][];
            var data = Uint16Bytes(loadNumber).Concat(unknownArgs).Concat(new[] {lineCount});
            for (var i = 0; i < lineCount; i++) {
                switch (reader.PeekByte()) {
                    case 0xff:
                        animationData[i] = reader.ReadBytes(3);
                        break;
                    case 0xfe:
                        animationData[i] = reader.ReadBytes(2);
                        break;
                    default:
                        animationData[i] = reader.ReadBytes(10);
                        break;
                }
                data = data.Concat(animationData[i]);
            }
            ActionData = data.ToArray();
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tMakeAnimation(0x{1:X4} {2} {3} {4}", Offset, loadNumber, BitConverter.ToString(unknownArgs), lineCount, Arr2String(animationData));
        }
    }

    public class ReadFormat : Command
    {
        private byte fmtLineCount;
        private byte unknownArg;
        private byte[][] formatData;
        public ReadFormat(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            unknownArg = reader.ReadByte();
            fmtLineCount = reader.ReadByte();
            formatData = new byte[fmtLineCount][];
            var data = new[] {unknownArg}.Concat(new[] {fmtLineCount});
            for (var i = 0; i < fmtLineCount; i++) {
                formatData[i] = reader.ReadBytes(8);
                data = data.Concat(formatData[i]);
            }
            ActionData = data.ToArray();
        }
        public override string ToString() {
            return $"[{Offset:X4}]\tReadFormat({fmtLineCount:X2} {unknownArg:X2}, {Arr2String(formatData)})";
        }
    }

    public class ScreenEffect : Command
    {
        private byte unknown1;
        private byte unknown2;
        private byte screenEffect;
        private ushort effectTime;
        public ScreenEffect(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            unknown1 = reader.ReadByte();
            unknown2 = reader.ReadByte();
            screenEffect = reader.ReadByte();
            effectTime = reader.ReadUint16();
            ActionData =
                new[] {unknown1}.Concat(new[] {unknown2})
                    .Concat(new[] {screenEffect})
                    .Concat(Uint16Bytes(effectTime))
                    .ToArray();
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tScreenEffect({1:X2} {2:X2} {3:X2} {4:X4}", Offset, unknown1, unknown2, screenEffect,
                effectTime);
        }
    }

    public class LoadBattleMap : Command
    {
        private ushort loadNumber;
        public LoadBattleMap(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            loadNumber = reader.ReadUint16();
            ActionData = Uint16Bytes(loadNumber);
            //$script:currentObject["loadResource"] = $resources[$loadNumber].textString
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tLoadBattleMap(0x{1:X4})", Offset, loadNumber);
        }
    }

    public class LoadScene : Command
    {
        private byte sceneFileVar;
        private byte scenePartVar;
        public LoadScene(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            sceneFileVar = reader.ReadByte();
            scenePartVar = reader.ReadByte();
            ActionData = new[] {sceneFileVar, scenePartVar};
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tLoadScene(file=${1:X2}, part=${2:X2})", Offset, sceneFileVar, scenePartVar);
        }
    }

    public class LoadMusic : Command
    {
        private ushort loadNmber;
        public LoadMusic(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            loadNmber = reader.ReadUint16();
            ActionData = Uint16Bytes(loadNmber);
            /*$loadNumber = ([int]$script:currentObject["actionData"][1] -shl 8) + [int]$script:currentObject["actionData"][0]
	$script:currentObject["loadResource"] = $resources[$loadNumber].textString

	$musicFile = [System.IO.File]::ReadAllBytes(($gameDir + $resources[$loadNumber].textString))
	$musStrings = @()
	11,5,9,7 | % {
		$start = (([int]$musicFile[$musicFile.Count - $_] -shl 8) + $musicFile[$musicFile.Count - $_ - 1])+1
		$currentString = @()
		while ($musicFile[$start]) {
			$currentString += $musicFile[$start]
			$start++
		}
		$musStrings += [System.Text.Encoding]::GetEncoding("shift-jis").GetString($currentString)
	}
	$script:currentObject["musicTitle1"] = $musStrings[0]
	$script:currentObject["musicTitle2"] = $musStrings[1]
	$script:currentObject["musicAuthor1"] = $musStrings[2]
	$script:currentObject["musicAuthor2"] = $musStrings[3]*/
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tLoadMusic({1:X4})", Offset, loadNmber);
        }
    }

    public class InitScreenRegion : Command
    {
        private byte[] args;
        public byte Arg1 { get; set; }
        public ushort Arg2 { get; set; }
        public byte Arg3 { get; set; }
        public ushort Arg4 { get; set; }
        public ushort Arg5 { get; set; }
        public byte Arg6 { get; set; }

        public InitScreenRegion(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            args = reader.ReadBytes(9);
            ActionData = args;
            SetArgs();
        }

        private void SetArgs() {
            Arg1 = args[0];
            //Arg2 = (ushort) ((args[2] << 8) + args[1]);
            Arg2 = GetUshort(args, 1);
            Arg3 = args[3];
            //Arg4 = (ushort) ((args[5] << 8) + args[4]);
            Arg4 = GetUshort(args, 4);
            //Arg5 = (ushort) ((args[7] << 8) + args[6]);
            Arg5 = GetUshort(args, 6);
            Arg6 = args[8];
        }

        public override string ToString() {
            return $"[{Offset:X4}]\tInitScreenRegion({BitConverter.ToString(args)})";
        }
        public override bool HasArgChanges() {
            if (args[0] != Arg1) {
                return true;
            }
            if (GetUshort(args, 1) != Arg2) {
                return true;
            }
            if (Arg3 != args[3]) {
                return true;
            }
            if (GetUshort(args, 4) != Arg4) {
                return true;
            }
            if (GetUshort(args, 6) != Arg5) {
                return true;
            }
            return Arg6 != args[8];
        }

        public override void ResetArgs() {
            SetArgs();
        }

        public override void LoadTranslation(TranslationRow translation) {
            var trArgs = translation.Args;
            if (trArgs.Count < 9) {
                return;
            }
            Arg1 = trArgs[0];
            Arg2 = GetUshort(trArgs, 1);
            Arg3 = trArgs[3];
            Arg4 = GetUshort(trArgs, 4);
            Arg5 = GetUshort(trArgs, 6);
            Arg6 = trArgs[8];
        }

        public override TranslationRow ExtractTranslation() {
            if (!HasArgChanges()) {
                return null;
            }
            
            var tr = new TranslationRow {
                Filename = Path.GetFileName(FileName),
                Offset = Offset,
                Code = ActionCode,
                Original = OriginalText(),
                Translation = ""
            };
            var trArgs = CompileArgs();
            tr.Args = trArgs;
            return tr;
        }

        private List<byte> CompileArgs() {
            var trArgs = new List<byte>();
            trArgs.Add(Arg1);
            trArgs.AddRange(Uint16Bytes(Arg2));
            trArgs.Add(Arg3);
            trArgs.AddRange(Uint16Bytes(Arg4));
            trArgs.AddRange(Uint16Bytes(Arg5));
            trArgs.Add(Arg6);
            return trArgs;
        }

        public override byte[] Compile() {
            if (HasArgChanges()) {
                CompiledActionData = new byte[] {ActionCode}.Concat(CompileArgs()).ToArray();
            } else {
                CompiledActionData = new[] {ActionCode}.Concat(args).ToArray();
            }
            return CompiledActionData;
        }
    }

    public class MakeTextField : Command
    {
        private byte[] args;
        public MakeTextField(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            args = reader.ReadBytes(22);
            ActionData = args;
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tMakeTextField({1})", Offset, BitConverter.ToString(args));
        }
    }

    public class MakeField : Command
    {
        private byte[] args;
        public MakeField(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            args = reader.ReadBytes(6);
            ActionData = args;
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tMakeField({1})", Offset, BitConverter.ToString(args));
        }
    }

    public class DrawField : Command
    {
        private byte[] args;
        public DrawField(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            args = reader.ReadBytes(5);
            ActionData = args;
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tDrawField({1})", Offset, BitConverter.ToString(args));
        }
    }

    public class LoadPicture2 : Command
    {
        private string loadResource;
        private ushort loadNumber;
        private byte pictureX;
        private byte pictureY;
        private byte pictureCorner;
        private byte pictureUnknown1;
        private byte screenWhiteTime;
        private ushort fadeInTime;
        public LoadPicture2(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            //$script:currentObject["loadResource"] = $resources[$loadNumber].textString
            loadNumber = reader.ReadUint16();
            pictureX = reader.ReadByte();
            pictureY = reader.ReadByte();
            pictureCorner = reader.ReadByte();
            pictureUnknown1 = reader.ReadByte();
            screenWhiteTime = reader.ReadByte();
            fadeInTime = reader.ReadUint16();
            ActionData =
                Uint16Bytes(loadNumber)
                    .Concat(new[] {pictureX})
                    .Concat(new[] {pictureY})
                    .Concat(new[] {pictureCorner})
                    .Concat(new[] {pictureUnknown1})
                    .Concat(new[] {screenWhiteTime})
                    .Concat(Uint16Bytes(fadeInTime)).ToArray();
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tLoadPicture2({1:X4} {2:X2} {3:X2} {4:X2} {5:X2} {6:X2} {7:X4})", Offset, loadNumber, pictureX,
                pictureY, pictureCorner, pictureUnknown1, screenWhiteTime, fadeInTime);
        }
    }

    public class LoadPicture1 : Command
    {
        private byte[] args;
        public LoadPicture1(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            args = reader.ReadBytes(16);
            ActionData = args;
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tLoadPicture1({1})", Offset, BitConverter.ToString(args));
        }
    }
}
