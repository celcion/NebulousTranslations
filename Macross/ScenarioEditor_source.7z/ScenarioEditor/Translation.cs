﻿using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace ScenarioEditor {
    [XmlRoot("Translation")]
    public class TranslationRow {
        public string Filename { get; set; }
        public ushort Offset { get; set; }
        public string Original { get; set; }
        public List<string> OriginalArray { get; set; }
        public string Translation { get; set; }
        public List<string> TranslationArray { get; set; }
        public byte Code { get; set; }
        public string StringEnd { get; set; }
        public List<TranslationRow> NestedRows { get; set; }
        public bool WaitTerminated { get; set; }
        public bool IsDelimiter { get; set; }
        public bool IsVerified { get; set; }
        public byte ArgX { get; set; }
        public ushort ArgY { get; set; }
        public ushort ArgVSpace { get; set; }
        public List<byte> Args { get; set; }
        public DateTime LastChanged { get; set; }

        public void Normalize() {
            if (!string.IsNullOrEmpty(Translation)) {
                Translation = Translation.Replace("\r\n", "[LBR]").Replace("\n", "[LBR]").Replace("[LBR]", "\r\n").TrimStart().TrimEnd();
            }
        }
    }

    public class Translation {
        [XmlArray("Translations"), XmlArrayItem(typeof(TranslationRow), ElementName = "Row")]
        public List<TranslationRow> Translations { get; set; }
    }
}