﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScenarioEditor
{
    public class CopyVar : Command
    {
        public byte CopyTo { get; }
        public byte CopyFrom { get; }

        public CopyVar(byte cmd, FileReader reader) : base(cmd, reader) {
            this.IsText = false;
            CopyTo = reader.ReadByte();
            CopyFrom = reader.ReadByte();
            ActionData = new[] {CopyTo, CopyFrom};
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\t${1:X2} = ${2:X2}", Offset, CopyTo, CopyFrom);
        }

        public override byte[] Compile() {
            CompiledActionData = new[] {ActionCode, CopyTo, CopyFrom};
            return CompiledActionData;
        }
    }

    public class SetVar : Command
    {
        public byte VarAddr { get; }
        public ushort VarValue { get; set; }
        public ushort CompiledVarValue { get; set; }

        public SetVar(byte cmd, FileReader reader) : base(cmd, reader) {
            this.IsText = false;
            VarAddr = reader.ReadByte();
            VarValue = reader.ReadUint16();
            ActionData = new[] {VarAddr}.Concat(Uint16Bytes(VarValue)).ToArray();
            CompiledVarValue = VarValue;
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\t${1:X2} = 0x{2:X4}", Offset, VarAddr, VarValue);
        }

        public override byte[] Compile() {
            CompiledActionData = new[] { ActionCode, VarAddr }.Concat(Uint16Bytes(CompiledVarValue)).ToArray();
            return CompiledActionData;
        }
    }
}
