﻿namespace ScenarioEditor
{
    partial class TranslationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TranslationForm));
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.bOpenDir = new System.Windows.Forms.ToolStripButton();
            this.bOpenTranslation = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bSaveTranslation = new System.Windows.Forms.ToolStripButton();
            this.bCompile = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.tbSearch = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.bShowCommands = new System.Windows.Forms.ToolStripButton();
            this.tbCopyText = new System.Windows.Forms.ToolStripButton();
            this.tbTranslateRepeated = new System.Windows.Forms.ToolStripButton();
            this.tbTranslateAllFiles = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lbFiles = new System.Windows.Forms.ListBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.pLoading = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lbStrings = new System.Windows.Forms.ListBox();
            this.cMenu = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copyOriginalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tabTranslationPane = new System.Windows.Forms.TabControl();
            this.tabText = new System.Windows.Forms.TabPage();
            this.splitContainer3 = new System.Windows.Forms.SplitContainer();
            this.tbOriginalText = new System.Windows.Forms.TextBox();
            this.splitContainer4 = new System.Windows.Forms.SplitContainer();
            this.elementHost1 = new System.Windows.Forms.Integration.ElementHost();
            this.tbPreview = new System.Windows.Forms.TextBox();
            this.tabTable = new System.Windows.Forms.TabPage();
            this.dgTranslation = new System.Windows.Forms.DataGridView();
            this.Original = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Translation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OldTranslation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tpLoadOnKeyPress = new System.Windows.Forms.TabPage();
            this.bLoadOnKeyPressReset = new System.Windows.Forms.Button();
            this.nudLoadOnKeyPressPart = new System.Windows.Forms.NumericUpDown();
            this.nudLoadOnKeyPressNumber = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tpInitScreenRegion = new System.Windows.Forms.TabPage();
            this.b11_reset = new System.Windows.Forms.Button();
            this.nud11_6 = new System.Windows.Forms.NumericUpDown();
            this.nud11_5 = new System.Windows.Forms.NumericUpDown();
            this.nud11_4 = new System.Windows.Forms.NumericUpDown();
            this.nud11_3 = new System.Windows.Forms.NumericUpDown();
            this.nud11_2 = new System.Windows.Forms.NumericUpDown();
            this.nud11_1 = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bReset = new System.Windows.Forms.Button();
            this.nudStringCount = new System.Windows.Forms.NumericUpDown();
            this.lStringCount = new System.Windows.Forms.Label();
            this.nudFont = new System.Windows.Forms.NumericUpDown();
            this.lFont = new System.Windows.Forms.Label();
            this.nudSize = new System.Windows.Forms.NumericUpDown();
            this.lSize = new System.Windows.Forms.Label();
            this.nudVerticalSpace = new System.Windows.Forms.NumericUpDown();
            this.lVspace = new System.Windows.Forms.Label();
            this.nudY = new System.Windows.Forms.NumericUpDown();
            this.lY = new System.Windows.Forms.Label();
            this.nudX = new System.Windows.Forms.NumericUpDown();
            this.lLeft = new System.Windows.Forms.Label();
            this.cbTranslationIsVerified = new System.Windows.Forms.CheckBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel1 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsTranslatedLines = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel2 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsLineCount = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsTranslationPercent = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsChanged = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStripStatusLabel3 = new System.Windows.Forms.ToolStripStatusLabel();
            this.tsCommandArgs = new System.Windows.Forms.ToolStripStatusLabel();
            this.bImport = new System.Windows.Forms.ToolStripButton();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            this.pLoading.SuspendLayout();
            this.cMenu.SuspendLayout();
            this.tabTranslationPane.SuspendLayout();
            this.tabText.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).BeginInit();
            this.splitContainer3.Panel1.SuspendLayout();
            this.splitContainer3.Panel2.SuspendLayout();
            this.splitContainer3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).BeginInit();
            this.splitContainer4.Panel1.SuspendLayout();
            this.splitContainer4.Panel2.SuspendLayout();
            this.splitContainer4.SuspendLayout();
            this.tabTable.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgTranslation)).BeginInit();
            this.tpLoadOnKeyPress.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudLoadOnKeyPressPart)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLoadOnKeyPressNumber)).BeginInit();
            this.tpInitScreenRegion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudStringCount)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFont)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSize)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVerticalSpace)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudY)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudX)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bOpenDir,
            this.bOpenTranslation,
            this.bImport,
            this.toolStripSeparator1,
            this.bSaveTranslation,
            this.bCompile,
            this.toolStripSeparator2,
            this.tbSearch,
            this.toolStripSeparator3,
            this.bShowCommands,
            this.tbCopyText,
            this.tbTranslateRepeated,
            this.tbTranslateAllFiles});
            this.toolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1189, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // bOpenDir
            // 
            this.bOpenDir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bOpenDir.Image = ((System.Drawing.Image)(resources.GetObject("bOpenDir.Image")));
            this.bOpenDir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bOpenDir.Name = "bOpenDir";
            this.bOpenDir.Size = new System.Drawing.Size(40, 22);
            this.bOpenDir.Text = "Open";
            this.bOpenDir.ToolTipText = "Open directory";
            this.bOpenDir.Click += new System.EventHandler(this.bOpenDir_Click);
            // 
            // bOpenTranslation
            // 
            this.bOpenTranslation.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bOpenTranslation.Image = ((System.Drawing.Image)(resources.GetObject("bOpenTranslation.Image")));
            this.bOpenTranslation.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bOpenTranslation.Name = "bOpenTranslation";
            this.bOpenTranslation.Size = new System.Drawing.Size(37, 22);
            this.bOpenTranslation.Text = "Load";
            this.bOpenTranslation.ToolTipText = "Load translation file";
            this.bOpenTranslation.Click += new System.EventHandler(this.bOpenTranslation_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bSaveTranslation
            // 
            this.bSaveTranslation.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bSaveTranslation.Image = ((System.Drawing.Image)(resources.GetObject("bSaveTranslation.Image")));
            this.bSaveTranslation.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bSaveTranslation.Name = "bSaveTranslation";
            this.bSaveTranslation.Size = new System.Drawing.Size(35, 22);
            this.bSaveTranslation.Text = "Save";
            this.bSaveTranslation.ToolTipText = "Save translation file. Shift+Click to select another file";
            this.bSaveTranslation.Click += new System.EventHandler(this.bSaveTranslation_Click);
            // 
            // bCompile
            // 
            this.bCompile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bCompile.Image = ((System.Drawing.Image)(resources.GetObject("bCompile.Image")));
            this.bCompile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bCompile.Name = "bCompile";
            this.bCompile.Size = new System.Drawing.Size(83, 22);
            this.bCompile.Text = "Compile BINs";
            this.bCompile.ToolTipText = "Compile BINs (SHIFT + click to select another directory)";
            this.bCompile.Click += new System.EventHandler(this.bCompile_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // tbSearch
            // 
            this.tbSearch.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(250, 25);
            this.tbSearch.Text = "Search (press <F3> to next occurence)";
            this.tbSearch.ToolTipText = "Enter search string and press <Enter>. Press <F3> to find next occurrence";
            this.tbSearch.KeyDown += new System.Windows.Forms.KeyEventHandler(this.tbSearch_KeyDown);
            this.tbSearch.Click += new System.EventHandler(this.tbSearch_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 25);
            // 
            // bShowCommands
            // 
            this.bShowCommands.Alignment = System.Windows.Forms.ToolStripItemAlignment.Right;
            this.bShowCommands.CheckOnClick = true;
            this.bShowCommands.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bShowCommands.Image = ((System.Drawing.Image)(resources.GetObject("bShowCommands.Image")));
            this.bShowCommands.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bShowCommands.Name = "bShowCommands";
            this.bShowCommands.Size = new System.Drawing.Size(103, 22);
            this.bShowCommands.Text = "Show commands";
            this.bShowCommands.Click += new System.EventHandler(this.bShowCommands_Click);
            // 
            // tbCopyText
            // 
            this.tbCopyText.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tbCopyText.Image = ((System.Drawing.Image)(resources.GetObject("tbCopyText.Image")));
            this.tbCopyText.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbCopyText.Name = "tbCopyText";
            this.tbCopyText.Size = new System.Drawing.Size(82, 22);
            this.tbCopyText.Text = "Copy original";
            this.tbCopyText.Click += new System.EventHandler(this.tbCopyText_Click);
            // 
            // tbTranslateRepeated
            // 
            this.tbTranslateRepeated.CheckOnClick = true;
            this.tbTranslateRepeated.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tbTranslateRepeated.Image = ((System.Drawing.Image)(resources.GetObject("tbTranslateRepeated.Image")));
            this.tbTranslateRepeated.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbTranslateRepeated.Name = "tbTranslateRepeated";
            this.tbTranslateRepeated.Size = new System.Drawing.Size(145, 22);
            this.tbTranslateRepeated.Text = "Translate repeated strings";
            this.tbTranslateRepeated.ToolTipText = "Translate repeated strings";
            // 
            // tbTranslateAllFiles
            // 
            this.tbTranslateAllFiles.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tbTranslateAllFiles.Image = ((System.Drawing.Image)(resources.GetObject("tbTranslateAllFiles.Image")));
            this.tbTranslateAllFiles.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tbTranslateAllFiles.Name = "tbTranslateAllFiles";
            this.tbTranslateAllFiles.Size = new System.Drawing.Size(92, 22);
            this.tbTranslateAllFiles.Text = "Copy to all files";
            this.tbTranslateAllFiles.ToolTipText = "Copy current string\'s translation to all files";
            this.tbTranslateAllFiles.Click += new System.EventHandler(this.tbTranslateAllFiles_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lbFiles);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Size = new System.Drawing.Size(1189, 688);
            this.splitContainer1.SplitterDistance = 163;
            this.splitContainer1.TabIndex = 1;
            // 
            // lbFiles
            // 
            this.lbFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbFiles.FormattingEnabled = true;
            this.lbFiles.Location = new System.Drawing.Point(0, 0);
            this.lbFiles.Name = "lbFiles";
            this.lbFiles.Size = new System.Drawing.Size(163, 688);
            this.lbFiles.TabIndex = 0;
            this.lbFiles.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lbFiles_DrawItem);
            this.lbFiles.SelectedIndexChanged += new System.EventHandler(this.lbFiles_SelectedIndexChanged);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.pLoading);
            this.splitContainer2.Panel1.Controls.Add(this.lbStrings);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.tabTranslationPane);
            this.splitContainer2.Panel2.Controls.Add(this.panel1);
            this.splitContainer2.Size = new System.Drawing.Size(1022, 688);
            this.splitContainer2.SplitterDistance = 445;
            this.splitContainer2.TabIndex = 0;
            // 
            // pLoading
            // 
            this.pLoading.Controls.Add(this.label1);
            this.pLoading.Location = new System.Drawing.Point(182, 181);
            this.pLoading.Name = "pLoading";
            this.pLoading.Size = new System.Drawing.Size(378, 141);
            this.pLoading.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(155, 58);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Loading...";
            // 
            // lbStrings
            // 
            this.lbStrings.ContextMenuStrip = this.cMenu;
            this.lbStrings.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbStrings.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lbStrings.FormattingEnabled = true;
            this.lbStrings.Location = new System.Drawing.Point(0, 0);
            this.lbStrings.Name = "lbStrings";
            this.lbStrings.Size = new System.Drawing.Size(1022, 445);
            this.lbStrings.TabIndex = 0;
            this.lbStrings.DrawItem += new System.Windows.Forms.DrawItemEventHandler(this.lbStrings_DrawItem);
            this.lbStrings.SelectedIndexChanged += new System.EventHandler(this.lbStrings_SelectedIndexChanged);
            this.lbStrings.DoubleClick += new System.EventHandler(this.lbStrings_DoubleClick);
            this.lbStrings.KeyDown += new System.Windows.Forms.KeyEventHandler(this.lbStrings_KeyDown);
            // 
            // cMenu
            // 
            this.cMenu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyOriginalToolStripMenuItem});
            this.cMenu.Name = "cMenu";
            this.cMenu.Size = new System.Drawing.Size(146, 26);
            // 
            // copyOriginalToolStripMenuItem
            // 
            this.copyOriginalToolStripMenuItem.Name = "copyOriginalToolStripMenuItem";
            this.copyOriginalToolStripMenuItem.Size = new System.Drawing.Size(145, 22);
            this.copyOriginalToolStripMenuItem.Text = "Copy original";
            this.copyOriginalToolStripMenuItem.Click += new System.EventHandler(this.mCopyOriginal_Click);
            // 
            // tabTranslationPane
            // 
            this.tabTranslationPane.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabTranslationPane.Controls.Add(this.tabText);
            this.tabTranslationPane.Controls.Add(this.tabTable);
            this.tabTranslationPane.Controls.Add(this.tpLoadOnKeyPress);
            this.tabTranslationPane.Controls.Add(this.tpInitScreenRegion);
            this.tabTranslationPane.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabTranslationPane.ItemSize = new System.Drawing.Size(60, 20);
            this.tabTranslationPane.Location = new System.Drawing.Point(0, 0);
            this.tabTranslationPane.Name = "tabTranslationPane";
            this.tabTranslationPane.SelectedIndex = 0;
            this.tabTranslationPane.Size = new System.Drawing.Size(1022, 218);
            this.tabTranslationPane.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabTranslationPane.TabIndex = 0;
            this.tabTranslationPane.Selecting += new System.Windows.Forms.TabControlCancelEventHandler(this.tabTranslationPane_Selecting);
            // 
            // tabText
            // 
            this.tabText.Controls.Add(this.splitContainer3);
            this.tabText.Location = new System.Drawing.Point(4, 24);
            this.tabText.Name = "tabText";
            this.tabText.Padding = new System.Windows.Forms.Padding(3);
            this.tabText.Size = new System.Drawing.Size(1014, 190);
            this.tabText.TabIndex = 0;
            this.tabText.UseVisualStyleBackColor = true;
            // 
            // splitContainer3
            // 
            this.splitContainer3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer3.Location = new System.Drawing.Point(3, 3);
            this.splitContainer3.Name = "splitContainer3";
            // 
            // splitContainer3.Panel1
            // 
            this.splitContainer3.Panel1.Controls.Add(this.tbOriginalText);
            // 
            // splitContainer3.Panel2
            // 
            this.splitContainer3.Panel2.Controls.Add(this.splitContainer4);
            this.splitContainer3.Size = new System.Drawing.Size(1008, 184);
            this.splitContainer3.SplitterDistance = 293;
            this.splitContainer3.TabIndex = 0;
            // 
            // tbOriginalText
            // 
            this.tbOriginalText.ContextMenuStrip = this.cMenu;
            this.tbOriginalText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbOriginalText.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbOriginalText.Location = new System.Drawing.Point(0, 0);
            this.tbOriginalText.Multiline = true;
            this.tbOriginalText.Name = "tbOriginalText";
            this.tbOriginalText.ReadOnly = true;
            this.tbOriginalText.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbOriginalText.Size = new System.Drawing.Size(293, 184);
            this.tbOriginalText.TabIndex = 0;
            this.tbOriginalText.DoubleClick += new System.EventHandler(this.tbOriginalText_DoubleClick);
            // 
            // splitContainer4
            // 
            this.splitContainer4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer4.Location = new System.Drawing.Point(0, 0);
            this.splitContainer4.Name = "splitContainer4";
            // 
            // splitContainer4.Panel1
            // 
            this.splitContainer4.Panel1.Controls.Add(this.elementHost1);
            // 
            // splitContainer4.Panel2
            // 
            this.splitContainer4.Panel2.Controls.Add(this.tbPreview);
            this.splitContainer4.Size = new System.Drawing.Size(711, 184);
            this.splitContainer4.SplitterDistance = 358;
            this.splitContainer4.TabIndex = 1;
            // 
            // elementHost1
            // 
            this.elementHost1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.elementHost1.Location = new System.Drawing.Point(0, 0);
            this.elementHost1.Name = "elementHost1";
            this.elementHost1.Size = new System.Drawing.Size(358, 184);
            this.elementHost1.TabIndex = 1;
            this.elementHost1.Text = "elementHost1";
            this.elementHost1.Child = null;
            // 
            // tbPreview
            // 
            this.tbPreview.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tbPreview.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPreview.Location = new System.Drawing.Point(0, 0);
            this.tbPreview.Multiline = true;
            this.tbPreview.Name = "tbPreview";
            this.tbPreview.ReadOnly = true;
            this.tbPreview.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.tbPreview.Size = new System.Drawing.Size(349, 184);
            this.tbPreview.TabIndex = 0;
            // 
            // tabTable
            // 
            this.tabTable.Controls.Add(this.dgTranslation);
            this.tabTable.Location = new System.Drawing.Point(4, 24);
            this.tabTable.Name = "tabTable";
            this.tabTable.Padding = new System.Windows.Forms.Padding(3);
            this.tabTable.Size = new System.Drawing.Size(1014, 190);
            this.tabTable.TabIndex = 1;
            this.tabTable.UseVisualStyleBackColor = true;
            // 
            // dgTranslation
            // 
            this.dgTranslation.AllowUserToAddRows = false;
            this.dgTranslation.AllowUserToDeleteRows = false;
            this.dgTranslation.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgTranslation.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Original,
            this.Translation,
            this.OldTranslation});
            this.dgTranslation.ContextMenuStrip = this.cMenu;
            this.dgTranslation.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dgTranslation.Location = new System.Drawing.Point(3, 3);
            this.dgTranslation.Name = "dgTranslation";
            this.dgTranslation.Size = new System.Drawing.Size(1008, 184);
            this.dgTranslation.TabIndex = 0;
            // 
            // Original
            // 
            this.Original.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Original.DataPropertyName = "Original";
            this.Original.HeaderText = "Original";
            this.Original.Name = "Original";
            this.Original.ReadOnly = true;
            this.Original.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Translation
            // 
            this.Translation.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.Translation.DataPropertyName = "Translation";
            this.Translation.HeaderText = "Translation";
            this.Translation.Name = "Translation";
            this.Translation.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // OldTranslation
            // 
            this.OldTranslation.HeaderText = "OldTranslation";
            this.OldTranslation.Name = "OldTranslation";
            this.OldTranslation.Visible = false;
            // 
            // tpLoadOnKeyPress
            // 
            this.tpLoadOnKeyPress.Controls.Add(this.bLoadOnKeyPressReset);
            this.tpLoadOnKeyPress.Controls.Add(this.nudLoadOnKeyPressPart);
            this.tpLoadOnKeyPress.Controls.Add(this.nudLoadOnKeyPressNumber);
            this.tpLoadOnKeyPress.Controls.Add(this.label3);
            this.tpLoadOnKeyPress.Controls.Add(this.label2);
            this.tpLoadOnKeyPress.Location = new System.Drawing.Point(4, 24);
            this.tpLoadOnKeyPress.Name = "tpLoadOnKeyPress";
            this.tpLoadOnKeyPress.Padding = new System.Windows.Forms.Padding(3);
            this.tpLoadOnKeyPress.Size = new System.Drawing.Size(1014, 190);
            this.tpLoadOnKeyPress.TabIndex = 2;
            this.tpLoadOnKeyPress.Text = "LoadOnKeyPress";
            this.tpLoadOnKeyPress.UseVisualStyleBackColor = true;
            // 
            // bLoadOnKeyPressReset
            // 
            this.bLoadOnKeyPressReset.Location = new System.Drawing.Point(25, 86);
            this.bLoadOnKeyPressReset.Name = "bLoadOnKeyPressReset";
            this.bLoadOnKeyPressReset.Size = new System.Drawing.Size(75, 23);
            this.bLoadOnKeyPressReset.TabIndex = 4;
            this.bLoadOnKeyPressReset.Text = "Reset";
            this.bLoadOnKeyPressReset.UseVisualStyleBackColor = true;
            // 
            // nudLoadOnKeyPressPart
            // 
            this.nudLoadOnKeyPressPart.Location = new System.Drawing.Point(103, 30);
            this.nudLoadOnKeyPressPart.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudLoadOnKeyPressPart.Name = "nudLoadOnKeyPressPart";
            this.nudLoadOnKeyPressPart.Size = new System.Drawing.Size(120, 20);
            this.nudLoadOnKeyPressPart.TabIndex = 3;
            // 
            // nudLoadOnKeyPressNumber
            // 
            this.nudLoadOnKeyPressNumber.Location = new System.Drawing.Point(103, 4);
            this.nudLoadOnKeyPressNumber.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nudLoadOnKeyPressNumber.Name = "nudLoadOnKeyPressNumber";
            this.nudLoadOnKeyPressNumber.Size = new System.Drawing.Size(120, 20);
            this.nudLoadOnKeyPressNumber.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 38);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Scene Part:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Load Number:";
            // 
            // tpInitScreenRegion
            // 
            this.tpInitScreenRegion.Controls.Add(this.b11_reset);
            this.tpInitScreenRegion.Controls.Add(this.nud11_6);
            this.tpInitScreenRegion.Controls.Add(this.nud11_5);
            this.tpInitScreenRegion.Controls.Add(this.nud11_4);
            this.tpInitScreenRegion.Controls.Add(this.nud11_3);
            this.tpInitScreenRegion.Controls.Add(this.nud11_2);
            this.tpInitScreenRegion.Controls.Add(this.nud11_1);
            this.tpInitScreenRegion.Controls.Add(this.label9);
            this.tpInitScreenRegion.Controls.Add(this.label8);
            this.tpInitScreenRegion.Controls.Add(this.label7);
            this.tpInitScreenRegion.Controls.Add(this.label6);
            this.tpInitScreenRegion.Controls.Add(this.label5);
            this.tpInitScreenRegion.Controls.Add(this.label4);
            this.tpInitScreenRegion.Location = new System.Drawing.Point(4, 24);
            this.tpInitScreenRegion.Name = "tpInitScreenRegion";
            this.tpInitScreenRegion.Padding = new System.Windows.Forms.Padding(3);
            this.tpInitScreenRegion.Size = new System.Drawing.Size(1014, 190);
            this.tpInitScreenRegion.TabIndex = 3;
            this.tpInitScreenRegion.Text = "InitScreenRegion";
            this.tpInitScreenRegion.UseVisualStyleBackColor = true;
            // 
            // b11_reset
            // 
            this.b11_reset.Location = new System.Drawing.Point(37, 122);
            this.b11_reset.Name = "b11_reset";
            this.b11_reset.Size = new System.Drawing.Size(75, 23);
            this.b11_reset.TabIndex = 12;
            this.b11_reset.Text = "Reset";
            this.b11_reset.UseVisualStyleBackColor = true;
            this.b11_reset.Click += new System.EventHandler(this.b11_reset_Click);
            // 
            // nud11_6
            // 
            this.nud11_6.Location = new System.Drawing.Point(336, 73);
            this.nud11_6.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud11_6.Name = "nud11_6";
            this.nud11_6.Size = new System.Drawing.Size(83, 20);
            this.nud11_6.TabIndex = 11;
            // 
            // nud11_5
            // 
            this.nud11_5.Location = new System.Drawing.Point(336, 39);
            this.nud11_5.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nud11_5.Name = "nud11_5";
            this.nud11_5.Size = new System.Drawing.Size(83, 20);
            this.nud11_5.TabIndex = 10;
            // 
            // nud11_4
            // 
            this.nud11_4.Location = new System.Drawing.Point(336, 9);
            this.nud11_4.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nud11_4.Name = "nud11_4";
            this.nud11_4.Size = new System.Drawing.Size(83, 20);
            this.nud11_4.TabIndex = 9;
            // 
            // nud11_3
            // 
            this.nud11_3.Location = new System.Drawing.Point(112, 73);
            this.nud11_3.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud11_3.Name = "nud11_3";
            this.nud11_3.Size = new System.Drawing.Size(83, 20);
            this.nud11_3.TabIndex = 8;
            // 
            // nud11_2
            // 
            this.nud11_2.Location = new System.Drawing.Point(112, 40);
            this.nud11_2.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nud11_2.Name = "nud11_2";
            this.nud11_2.Size = new System.Drawing.Size(83, 20);
            this.nud11_2.TabIndex = 7;
            // 
            // nud11_1
            // 
            this.nud11_1.Location = new System.Drawing.Point(112, 9);
            this.nud11_1.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nud11_1.Name = "nud11_1";
            this.nud11_1.Size = new System.Drawing.Size(83, 20);
            this.nud11_1.TabIndex = 6;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(250, 80);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(61, 13);
            this.label9.TabIndex = 5;
            this.label9.Text = "Arg 6 (byte)";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(250, 46);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(73, 13);
            this.label8.TabIndex = 4;
            this.label8.Text = "Arg 5 (uint 16)";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(250, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(73, 13);
            this.label7.TabIndex = 3;
            this.label7.Text = "Arg 4 (uint 16)";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(34, 80);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 13);
            this.label6.TabIndex = 2;
            this.label6.Text = "Arg 3 (byte)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(34, 46);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(73, 13);
            this.label5.TabIndex = 1;
            this.label5.Text = "Arg 2 (uint 16)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(34, 16);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Arg 1 (byte)";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.bReset);
            this.panel1.Controls.Add(this.nudStringCount);
            this.panel1.Controls.Add(this.lStringCount);
            this.panel1.Controls.Add(this.nudFont);
            this.panel1.Controls.Add(this.lFont);
            this.panel1.Controls.Add(this.nudSize);
            this.panel1.Controls.Add(this.lSize);
            this.panel1.Controls.Add(this.nudVerticalSpace);
            this.panel1.Controls.Add(this.lVspace);
            this.panel1.Controls.Add(this.nudY);
            this.panel1.Controls.Add(this.lY);
            this.panel1.Controls.Add(this.nudX);
            this.panel1.Controls.Add(this.lLeft);
            this.panel1.Controls.Add(this.cbTranslationIsVerified);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 218);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1022, 21);
            this.panel1.TabIndex = 2;
            // 
            // bReset
            // 
            this.bReset.Location = new System.Drawing.Point(905, -1);
            this.bReset.Name = "bReset";
            this.bReset.Size = new System.Drawing.Size(75, 23);
            this.bReset.TabIndex = 14;
            this.bReset.Text = "Reset";
            this.bReset.UseVisualStyleBackColor = true;
            this.bReset.Click += new System.EventHandler(this.bReset_Click);
            // 
            // nudStringCount
            // 
            this.nudStringCount.Location = new System.Drawing.Point(842, 0);
            this.nudStringCount.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudStringCount.Name = "nudStringCount";
            this.nudStringCount.ReadOnly = true;
            this.nudStringCount.Size = new System.Drawing.Size(41, 20);
            this.nudStringCount.TabIndex = 13;
            // 
            // lStringCount
            // 
            this.lStringCount.AutoSize = true;
            this.lStringCount.Location = new System.Drawing.Point(768, 4);
            this.lStringCount.Name = "lStringCount";
            this.lStringCount.Size = new System.Drawing.Size(67, 13);
            this.lStringCount.TabIndex = 12;
            this.lStringCount.Text = "String count:";
            // 
            // nudFont
            // 
            this.nudFont.Location = new System.Drawing.Point(692, 1);
            this.nudFont.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudFont.Name = "nudFont";
            this.nudFont.ReadOnly = true;
            this.nudFont.Size = new System.Drawing.Size(41, 20);
            this.nudFont.TabIndex = 11;
            // 
            // lFont
            // 
            this.lFont.AutoSize = true;
            this.lFont.Location = new System.Drawing.Point(659, 5);
            this.lFont.Name = "lFont";
            this.lFont.Size = new System.Drawing.Size(31, 13);
            this.lFont.TabIndex = 10;
            this.lFont.Text = "Font:";
            // 
            // nudSize
            // 
            this.nudSize.Location = new System.Drawing.Point(582, 1);
            this.nudSize.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudSize.Name = "nudSize";
            this.nudSize.ReadOnly = true;
            this.nudSize.Size = new System.Drawing.Size(41, 20);
            this.nudSize.TabIndex = 9;
            // 
            // lSize
            // 
            this.lSize.AutoSize = true;
            this.lSize.Location = new System.Drawing.Point(549, 5);
            this.lSize.Name = "lSize";
            this.lSize.Size = new System.Drawing.Size(30, 13);
            this.lSize.TabIndex = 8;
            this.lSize.Text = "Size:";
            // 
            // nudVerticalSpace
            // 
            this.nudVerticalSpace.Location = new System.Drawing.Point(468, 1);
            this.nudVerticalSpace.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nudVerticalSpace.Name = "nudVerticalSpace";
            this.nudVerticalSpace.Size = new System.Drawing.Size(53, 20);
            this.nudVerticalSpace.TabIndex = 7;
            // 
            // lVspace
            // 
            this.lVspace.AutoSize = true;
            this.lVspace.Location = new System.Drawing.Point(384, 5);
            this.lVspace.Name = "lVspace";
            this.lVspace.Size = new System.Drawing.Size(77, 13);
            this.lVspace.TabIndex = 6;
            this.lVspace.Text = "Vertical space:";
            // 
            // nudY
            // 
            this.nudY.Location = new System.Drawing.Point(298, 1);
            this.nudY.Maximum = new decimal(new int[] {
            65535,
            0,
            0,
            0});
            this.nudY.Name = "nudY";
            this.nudY.Size = new System.Drawing.Size(60, 20);
            this.nudY.TabIndex = 5;
            // 
            // lY
            // 
            this.lY.AutoSize = true;
            this.lY.Location = new System.Drawing.Point(276, 5);
            this.lY.Name = "lY";
            this.lY.Size = new System.Drawing.Size(17, 13);
            this.lY.TabIndex = 4;
            this.lY.Text = "Y:";
            // 
            // nudX
            // 
            this.nudX.Location = new System.Drawing.Point(202, 1);
            this.nudX.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.nudX.Name = "nudX";
            this.nudX.Size = new System.Drawing.Size(46, 20);
            this.nudX.TabIndex = 3;
            // 
            // lLeft
            // 
            this.lLeft.AutoSize = true;
            this.lLeft.Location = new System.Drawing.Point(147, 5);
            this.lLeft.Name = "lLeft";
            this.lLeft.Size = new System.Drawing.Size(52, 13);
            this.lLeft.TabIndex = 2;
            this.lLeft.Text = "X (chars):";
            // 
            // cbTranslationIsVerified
            // 
            this.cbTranslationIsVerified.AutoSize = true;
            this.cbTranslationIsVerified.Location = new System.Drawing.Point(3, 3);
            this.cbTranslationIsVerified.Name = "cbTranslationIsVerified";
            this.cbTranslationIsVerified.Size = new System.Drawing.Size(133, 17);
            this.cbTranslationIsVerified.TabIndex = 1;
            this.cbTranslationIsVerified.Text = "Translation is checked";
            this.cbTranslationIsVerified.UseVisualStyleBackColor = true;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel1,
            this.tsTranslatedLines,
            this.toolStripStatusLabel2,
            this.tsLineCount,
            this.tsTranslationPercent,
            this.tsChanged,
            this.toolStripStatusLabel3,
            this.tsCommandArgs});
            this.statusStrip1.Location = new System.Drawing.Point(0, 713);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(1189, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // toolStripStatusLabel1
            // 
            this.toolStripStatusLabel1.Name = "toolStripStatusLabel1";
            this.toolStripStatusLabel1.Size = new System.Drawing.Size(97, 17);
            this.toolStripStatusLabel1.Text = "Translated Lines: ";
            // 
            // tsTranslatedLines
            // 
            this.tsTranslatedLines.Name = "tsTranslatedLines";
            this.tsTranslatedLines.Size = new System.Drawing.Size(13, 17);
            this.tsTranslatedLines.Text = "0";
            // 
            // toolStripStatusLabel2
            // 
            this.toolStripStatusLabel2.Name = "toolStripStatusLabel2";
            this.toolStripStatusLabel2.Size = new System.Drawing.Size(12, 17);
            this.toolStripStatusLabel2.Text = "/";
            // 
            // tsLineCount
            // 
            this.tsLineCount.Name = "tsLineCount";
            this.tsLineCount.Size = new System.Drawing.Size(13, 17);
            this.tsLineCount.Text = "0";
            // 
            // tsTranslationPercent
            // 
            this.tsTranslationPercent.Name = "tsTranslationPercent";
            this.tsTranslationPercent.Size = new System.Drawing.Size(23, 17);
            this.tsTranslationPercent.Text = "0%";
            // 
            // tsChanged
            // 
            this.tsChanged.ForeColor = System.Drawing.Color.Red;
            this.tsChanged.Name = "tsChanged";
            this.tsChanged.Size = new System.Drawing.Size(55, 17);
            this.tsChanged.Text = "Changed";
            // 
            // toolStripStatusLabel3
            // 
            this.toolStripStatusLabel3.Name = "toolStripStatusLabel3";
            this.toolStripStatusLabel3.Size = new System.Drawing.Size(43, 17);
            this.toolStripStatusLabel3.Text = "     |      ";
            // 
            // tsCommandArgs
            // 
            this.tsCommandArgs.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.tsCommandArgs.Name = "tsCommandArgs";
            this.tsCommandArgs.Size = new System.Drawing.Size(16, 17);
            this.tsCommandArgs.Text = "...";
            this.tsCommandArgs.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // bImport
            // 
            this.bImport.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bImport.Image = ((System.Drawing.Image)(resources.GetObject("bImport.Image")));
            this.bImport.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bImport.Name = "bImport";
            this.bImport.Size = new System.Drawing.Size(47, 22);
            this.bImport.Text = "Import";
            this.bImport.ToolTipText = "Import (merge) another translation";
            this.bImport.Click += new System.EventHandler(this.bImport_Click);
            // 
            // TranslationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1189, 735);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.KeyPreview = true;
            this.Name = "TranslationForm";
            this.Text = "Macross - Translation";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.TranslationForm_FormClosing);
            this.Load += new System.EventHandler(this.TranslationForm_Load);
            this.Shown += new System.EventHandler(this.TranslationForm_Shown);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TranslationForm_KeyDown);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            this.pLoading.ResumeLayout(false);
            this.pLoading.PerformLayout();
            this.cMenu.ResumeLayout(false);
            this.tabTranslationPane.ResumeLayout(false);
            this.tabText.ResumeLayout(false);
            this.splitContainer3.Panel1.ResumeLayout(false);
            this.splitContainer3.Panel1.PerformLayout();
            this.splitContainer3.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer3)).EndInit();
            this.splitContainer3.ResumeLayout(false);
            this.splitContainer4.Panel1.ResumeLayout(false);
            this.splitContainer4.Panel2.ResumeLayout(false);
            this.splitContainer4.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer4)).EndInit();
            this.splitContainer4.ResumeLayout(false);
            this.tabTable.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgTranslation)).EndInit();
            this.tpLoadOnKeyPress.ResumeLayout(false);
            this.tpLoadOnKeyPress.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudLoadOnKeyPressPart)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudLoadOnKeyPressNumber)).EndInit();
            this.tpInitScreenRegion.ResumeLayout(false);
            this.tpInitScreenRegion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud11_1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nudStringCount)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudFont)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudSize)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudVerticalSpace)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudY)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudX)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton bOpenDir;
        private System.Windows.Forms.ToolStripButton bOpenTranslation;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton bSaveTranslation;
        private System.Windows.Forms.ToolStripButton bCompile;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripTextBox tbSearch;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.SplitContainer splitContainer2;
        private System.Windows.Forms.ListBox lbFiles;
        private System.Windows.Forms.ListBox lbStrings;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton bShowCommands;
        private System.Windows.Forms.TextBox tbOriginalText;
        private System.Windows.Forms.TabControl tabTranslationPane;
        private System.Windows.Forms.TabPage tabText;
        private System.Windows.Forms.SplitContainer splitContainer3;
        private System.Windows.Forms.TabPage tabTable;
        private System.Windows.Forms.DataGridView dgTranslation;
        private System.Windows.Forms.ToolStripButton tbCopyText;
        private System.Windows.Forms.ToolStripButton tbTranslateRepeated;
        private System.Windows.Forms.DataGridViewTextBoxColumn Original;
        private System.Windows.Forms.DataGridViewTextBoxColumn Translation;
        private System.Windows.Forms.DataGridViewTextBoxColumn OldTranslation;
        private System.Windows.Forms.ToolStripButton tbTranslateAllFiles;
        private System.Windows.Forms.Panel pLoading;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ContextMenuStrip cMenu;
        private System.Windows.Forms.ToolStripMenuItem copyOriginalToolStripMenuItem;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel1;
        private System.Windows.Forms.ToolStripStatusLabel tsLineCount;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel2;
        private System.Windows.Forms.ToolStripStatusLabel tsTranslatedLines;
        private System.Windows.Forms.ToolStripStatusLabel tsTranslationPercent;
        private System.Windows.Forms.ToolStripStatusLabel tsChanged;
        private System.Windows.Forms.SplitContainer splitContainer4;
        private System.Windows.Forms.TextBox tbPreview;
        private System.Windows.Forms.Integration.ElementHost elementHost1;
        private System.Windows.Forms.CheckBox cbTranslationIsVerified;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel3;
        private System.Windows.Forms.ToolStripStatusLabel tsCommandArgs;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lLeft;
        private System.Windows.Forms.NumericUpDown nudVerticalSpace;
        private System.Windows.Forms.Label lVspace;
        private System.Windows.Forms.NumericUpDown nudY;
        private System.Windows.Forms.Label lY;
        private System.Windows.Forms.NumericUpDown nudX;
        private System.Windows.Forms.NumericUpDown nudSize;
        private System.Windows.Forms.Label lSize;
        private System.Windows.Forms.NumericUpDown nudFont;
        private System.Windows.Forms.Label lFont;
        private System.Windows.Forms.NumericUpDown nudStringCount;
        private System.Windows.Forms.Label lStringCount;
        private System.Windows.Forms.Button bReset;
        private System.Windows.Forms.TabPage tpLoadOnKeyPress;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.NumericUpDown nudLoadOnKeyPressPart;
        private System.Windows.Forms.NumericUpDown nudLoadOnKeyPressNumber;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button bLoadOnKeyPressReset;
        private System.Windows.Forms.TabPage tpInitScreenRegion;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nud11_6;
        private System.Windows.Forms.NumericUpDown nud11_5;
        private System.Windows.Forms.NumericUpDown nud11_4;
        private System.Windows.Forms.NumericUpDown nud11_3;
        private System.Windows.Forms.NumericUpDown nud11_2;
        private System.Windows.Forms.NumericUpDown nud11_1;
        private System.Windows.Forms.Button b11_reset;
        private System.Windows.Forms.ToolStripButton bImport;
    }
}

