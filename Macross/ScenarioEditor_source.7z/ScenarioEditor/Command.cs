﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace ScenarioEditor {

    public class Command {
        public ushort Offset { get; }
        public ushort CompiledOffset { get; internal set; }
        public ushort CommandLength => (ushort) CompiledActionData.Length;
        public byte ActionCode { get; }
        public string StringEnd { get; set; }
        public byte[] ActionData { get; protected set; }
        public byte[] CompiledActionData { get; protected set; }
        public string FileName { get; }
        public string Action { get; }
        public bool IsText { get; protected set; }
        public virtual string Translation { get; set; }
        public bool IsMultiline { get; protected set; }
        public bool IsJump { get; protected set; }
        public bool IsContainer { get; set; }
        public List<Command> NestedCommands { get; set; }
        public bool IsVerified { get; set; }
        public DateTime LastChanged { get; set; }

        protected string Arr2String(byte[][] arg) {
            var res = "";
            foreach (byte[] b in arg) {
                if (res == "") {
                    res = BitConverter.ToString(b);
                } else {
                    res = res + " | " + BitConverter.ToString(b);
                }
            }
            return res;
        }

        public Command(byte cmd, FileReader reader) {
            NestedCommands = new List<Command>();
            ActionCode = cmd;
            Offset = reader.Seek;
            Offset--;
            FileName = reader.Filename;
            IsMultiline = false;
            Translation = "";
            ActionData = new byte[0];
            CompiledActionData = new[] { ActionCode }.Concat(ActionData).ToArray();
            IsJump = false;
            LastChanged = DateTime.MinValue;
        }

        public virtual void Append(Command cmd) {
            NestedCommands.Add(cmd);
        }

        public virtual bool IsSimilar(Command cmd) {
            return false;
        }

        public virtual string Text() {
            return "";
        }

        public virtual string OriginalText() {
            return "";
        }

        public virtual string[] OriginalTextMultiline() {
            return new string[0];
        }

        public virtual string ToString(bool original) {
            return this.ToString();
        }

        public virtual byte[] Compile() {
            CompiledActionData = new []{ActionCode}.Concat(ActionData).ToArray();
            return CompiledActionData;
        }

        public byte[] Uint16Bytes(ushort val) {
            var ret = new byte[]{0, 0};
            ret[0] = (byte) (val & 0x00FF);
            ret[1] = (byte) (val >> 8);
            return ret;
        }

        public ushort GetUshort(IList<byte> arr, int index) {
            return (ushort) ((arr[index + 1] << 8) + arr[index]);
        }

        public byte[] ArrayAppend(byte[] arr, byte[] add) {
            return arr.Concat(add).ToArray();
        }

        public byte[] ArrayAppend(byte[] arr, byte add) {
            return arr.Concat(new byte[]{add}).ToArray();
        }

        public byte[] ArrayAppend(byte[] arr, ushort add) {
            return arr.Concat(Uint16Bytes(add)).ToArray();
        }

        public byte[] ArrayAppend(ushort v1, byte v2) {
            return Uint16Bytes(v1).Concat(new byte[]{v2}).ToArray();
        }

        public string StrArgs() {
            return BitConverter.ToString(ActionData);
        }

        public virtual bool HasArgChanges() {
            return false;
        }

        public virtual void ResetArgs() {}

        public virtual void LoadTranslation(TranslationRow translation) {
        }

        public virtual TranslationRow ExtractTranslation() {
            return null;
        }
    }

    public class TranslationDataRow
    {
        public string Original { get; set; }
        public string Translation { get; set; }
        internal string OldTranslation { get; set; }
    }
}