﻿using System;

namespace ScenarioEditor {
    public class Magic13 : Command {
        private byte arg;

        public Magic13(byte cmd, FileReader reader) : base(cmd, reader) {
            arg = reader.ReadByte();
            IsText = false;
            ActionData = new[] {arg};
        }

        public override string ToString() {
            return String.Format("[{0:X4}]\tMagic13({1:X2})", Offset, arg);
        }
    }

    public class Unknown : Command
    {
        private byte[] args;
        private byte command;

        public Unknown(byte cmd, FileReader reader) : base(cmd, reader) {
            var len = 0;
            command = cmd;
            IsText = false;
            switch (cmd) {
                case 0x17:
                case 0x1d:
                case 0x28:
                case 0x3e:
                    len = 1;
                    break;
                case 0x21:
                case 0x23:
                case 0x29:
                case 0x35:
                    len = 2;
                    break;
                case 0x1e:
                case 0x30:
                case 0x31:
                case 0x37:
                case 0x38:
                case 0x39:
                case 0x3b:
                case 0x3f:
                case 0x41:
                case 0x42:
                case 0x43:
                case 0x44:
                    break;
                case 0x22:
                    len = 14;
                    break;
                case 0x24:
                    len = 6;
                    break;
                case 0x26:
                    len = 9;
                    break;
                case 0x27:
                case 0x33:
                case 0x36:
                case 0x3c:
                case 0x40:
                    len = 3;
                    break;
                case 0x34:
                    len = 4;
                    break;
            }
            args = len > 0 ? reader.ReadBytes(len) : new byte[0];
            ActionData = args;
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tcommand{1:X2}({2})", Offset, command, BitConverter.ToString(args));
        }
    }
}