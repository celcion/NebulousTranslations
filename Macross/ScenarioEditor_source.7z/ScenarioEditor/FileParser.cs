﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;

namespace ScenarioEditor {
    public class FileParser {
        public static ParsedFile Parse(string path) {
            var reader = new FileReader(path);
            var file = new ParsedFile();
            file.FileName = path;
            file.Offset = reader.ReadUint16();
            Debug.WriteLine("Offset: " + file.Offset);
            if (file.Offset > reader.Seek) {
                ushort r;
                do {
                    r = reader.ReadUint16();
                    Debug.WriteLine("Read ref " + r);
                    file.AddRef(r);
                } while (file.Offset > reader.Seek);
            }

            var commands = new List<Command>();
            Command prev = null;
            while (reader.Seek < reader.Length) {
                var cmd = reader.ReadByte();
                Command cobj = null;
                switch (cmd) {
                    case 0x00: case 0x01: case 0x02: case 0x03: case 0x04: case 0x05:
                        cobj = new ConditionalJump(cmd, reader);
                        break;
                    case 0x06:
                        cobj = new AlwaysJump(cmd, reader);
                        break;;
                    case 0x07:
                        cobj = new SetVar(cmd, reader);
                        break;
                    case 0x08:
                        cobj = new CopyVar(cmd, reader);
                        break;
                    case 0x09: case 0x0A: case 0x0b: case 0x0c:
                        cobj = new MathBinary(cmd, reader);
                        break;
                    case 0x0d: case 0x0e:
                        cobj = new MathUnary(cmd, reader);
                        break;
                    case 0x0f:
                        cobj = new LoadPicture1(cmd, reader);
                        break;
                    case 0x10:
                        cobj = new DrawField(cmd, reader);
                        break;
                    case 0x11:
                        cobj = new InitScreenRegion(cmd, reader);
                        break;
                    case 0x12:
                        cobj = new MakeField(cmd, reader);
                        break;
                    case 0x13:
                        cobj = new Magic13(cmd, reader);
                        break;
                    case 0x15:
                        cobj = new ScreenEffect(cmd, reader);
                        break;
                    case 0x16:
                        cobj = new MakeTextField(cmd, reader);
                        break;
                    case 0x17: case 0x1d: case 0x1e: case 0x21: case 0x22: case 0x23: case 0x24: case 0x26: case 0x27: case 0x28: case 0x29:
                    case 0x30: case 0x31: case 0x33: case 0x34: case 0x35: case 0x36: case 0x37: case 0x38: case 0x39: case 0x3b: case 0x3c:
                    case 0x3e: case 0x3f: case 0x40: case 0x41: case 0x42: case 0x43: case 0x44:
                        cobj = new Unknown(cmd, reader);
                        break;
                    case 0x18:
                        cobj = new OutputText(cmd, reader);
                        break;
                    case 0x19:
                        cobj = new OutputString(cmd, reader);
                        break;
                    case 0x1a:
                        cobj = new ReadFormat(cmd, reader);
                        break;
                    case 0x1b:
                        cobj = new LoadMusic(cmd, reader);
                        break;
                    case 0x1c:
                        cobj = new EventCheck(cmd, reader);
                        break;
                    case 0x1f:
                        cobj = new LoadScene(cmd, reader);
                        break;
                    case 0x20:
                        cobj = new TimedWait1(cmd, reader);
                        break;
                    case 0x25:
                        cobj = new MakeAnimation(cmd, reader);
                        break;
                    case 0x2a:
                        cobj = new LoadPicture2(cmd, reader);
                        break;
                    case 0x2b:
                    case 0x2c:
                        cobj = new Wait(cmd, reader);
                        break;
                    case 0x2e:
                        cobj = new ReadNextByte(cmd, reader);
                        break;
                    case 0x2f:
                        cobj = new TimedWait2(cmd, reader);
                        break;
                    case 0x32:
                        cobj = new LoadBattleMap(cmd, reader);
                        break;
                    case 0x3a:
                        cobj = new LoadOnKeyPress(cmd, reader);
                        break;
                    case 0x3d:
                        cobj = new TitleScreen(cmd, reader);
                        break;
                    case 0xff:
                        cobj = new ExitKey(cmd, reader);
                        break;
                }
                if (cobj != null) {
                    if (prev != null && prev.IsSimilar(cobj)) {
                        prev.Append(cobj);
                    } else {
                        commands.Add(cobj);
                        prev = cobj;
                    }
                    //Debug.WriteLine("{0:X4}: {1}", cobj.Offset, cobj);
                }
            }
            file.Commands = commands.ToArray();

            return file;
        }
    }

    
}