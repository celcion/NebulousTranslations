﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScenarioEditor
{


    public class MathUnary : Command
    {
        private byte var1;
        private string op;
        public MathUnary(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            var1 = reader.ReadByte();
            switch (cmd) {
                case 0x0d:
                    op = "++";
                    break;
                case 0x0e:
                    op = "--";
                    break;
            }
            ActionData = new[] {var1};
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\t${1:X2}{2}", Offset, var1, op);
        }
    }

    public class MathBinary : Command
    {
        private byte var1;
        private byte var2;
        private string op;
        public MathBinary(byte cmd, FileReader reader) : base(cmd, reader) {
            this.IsText = false;
            var1 = reader.ReadByte();
            var2 = reader.ReadByte();
            switch (cmd) {
                case 0x09:
                    op = "+";
                    break;
                case 0x0a:
                    op = "-";
                    break;
                case 0x0b:
                    op = "*";
                    break;
                case 0x0c:
                    op = "/";
                    break;
            }
            ActionData = new[] {var1, var2};
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\t${1:X2} = ${1:X2} {2} ${3:X2}", Offset, var1, op, var2);
        }
    }
}
