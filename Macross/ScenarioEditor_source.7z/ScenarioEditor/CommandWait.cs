﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScenarioEditor
{
    public class TimedWait1 : Command
    {
        private ushort waitTime;
        public TimedWait1(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            waitTime = reader.ReadUint16();
            ActionData = Uint16Bytes(waitTime);
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tTimedWait1(0x{1:X4})", Offset, waitTime);
        }
    }

    public class TimedWait2 : Command
    {
        private ushort waitTime;
        public TimedWait2(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
            waitTime = reader.ReadUint16();
            ActionData = Uint16Bytes(waitTime);
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tTimedWait2(0x{1:X4})", Offset, waitTime);
        }
    }

    public class Wait : Command
    {
        public Wait(byte cmd, FileReader reader) : base(cmd, reader) {
            IsText = false;
        }
        public override string ToString() {
            return String.Format("[{0:X4}]\tWait()", Offset);
        }
    }
}
