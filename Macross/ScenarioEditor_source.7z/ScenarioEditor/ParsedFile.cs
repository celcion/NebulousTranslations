﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;

namespace ScenarioEditor {
    public class ParsedFile {
        public string FileName { get; set; }
        public ushort Offset { get; set; }
        public ushort[]Refs { get; set; }
        public bool FullyTranslated { get; set; }

        public Command[] Commands { get; set; }
        public bool isEmptyChecked = false;
        public bool isEmpty;

        public ParsedFile() {
            Refs = new ushort[0];
        }

        public void AddRef(ushort newref) {
            var newarr = new ushort[Refs.Length + 1];
            for (var i = 0; i < Refs.Length; i++) {
                newarr[i] = Refs[i];
            }
            newarr[Refs.Length] = newref;
            Refs = newarr;
        }

        public bool  CheckTranslationStatus() {
            if (Commands.Any(cmd => cmd.IsText && (String.IsNullOrEmpty(cmd.Translation.Trim()) || cmd.Text() == cmd.Translation))) {
                FullyTranslated = false;
                return FullyTranslated;
            }
            FullyTranslated = true;
            return FullyTranslated;
        }

        public bool IsEmpty() {
            if (!isEmptyChecked) {
                if (Commands.Any(cmd => cmd.IsText)) {
                    isEmpty = false;
                    isEmptyChecked = true;
                    return isEmpty;
                }
                isEmptyChecked = true;
                isEmpty = true;
            }
            return isEmpty;
        }

        private Command FindCommand(ushort origOffset) {
            return Commands.FirstOrDefault(cmd => cmd.Offset == origOffset);
        }

        public bool Compile(string saveDir) {
            var offset = Offset;
            foreach (var cmd in Commands) {
                cmd.Compile();
                cmd.CompiledOffset = offset;
                offset = (ushort) (offset + cmd.CommandLength);
            }
            for (var i = 0; i < Commands.Length; i++) {
                var cmd = Commands[i];
                if (cmd.IsJump) {
                    var jumpVar = ((CommandJump) cmd).JumpVar;
                    if (jumpVar == 0x1b) {
                        // 1B исключение - это всегда прыжки по файлу в предварительно сохраненное место
                        continue;
                    }
                    for (var j = i; j >= 0; j--) {
                        var cmd1 = Commands[j];
                        if (cmd1.GetType() == typeof(SetVar)) {
                            var cmdvar = (SetVar) cmd1;
                            if (cmdvar.VarAddr == jumpVar) {
                                var cmdref = FindCommand(cmdvar.VarValue);
                                if (cmdref != null) {
                                    cmdvar.CompiledVarValue = cmdref.CompiledOffset;
                                    cmdvar.Compile();
                                } else {
                                    Debug.WriteLine("Can't find original reference {0:X2} = {1:X4} for jump {2}, assignment {3}", jumpVar, cmdvar.VarValue, cmd, cmdvar);
                                    return false;
                                }
                                break;
                            }
                        } else if (cmd1.GetType() == typeof(CopyVar)) {
                            jumpVar = ((CopyVar) cmd1).CopyFrom;
                        }
                    }
                } else if (cmd.GetType() == typeof(SetVar)) {
                    var cmd1 = cmd as SetVar;
                    if (cmd1.Offset == cmd1.VarValue) {
                        cmd1.CompiledVarValue = cmd1.CompiledOffset;
                        cmd1.Compile();
                    }
                }
            }
            if (FileName.Contains("K04_R03")) {
                // Хак с первым файлом
                // 1B по адресам 1457 и 165d получают значение не текущего адреса, а адреса самого первого 1B - 0xC
                SetVar first = null;
                ushort val = 0;
                foreach (var cmd in Commands) {
                    if (cmd.GetType() == typeof(SetVar)) {
                        var v = cmd as SetVar;
                        if (v.VarAddr == 0x1b) {
                            if (first == null) {
                                first = v;
                                val = (ushort) (first.CompiledOffset - 0xC);
                                Debug.WriteLine($"Found first 1b at offset {v.CompiledOffset:X2}");
                            } else if (v.Offset == 0x1457 || v.Offset == 0x165d) {
                                Debug.WriteLine($"Set value of {v.Offset:X2} to {val:X2}");
                                v.VarValue = val;
                            }
                        }
                    }
                }
            }
            if (FileName.Contains("K04_R10")) {
                // Хак со вторым файлом
                // 1B по адресам 0be8 и 0fd5 получают значение не текущего адреса, а адреса самого первого 1B
                SetVar first = null;
                foreach (var cmd in Commands) {
                    if (cmd.GetType() == typeof(SetVar)) {
                        var v = cmd as SetVar;
                        if (v.VarAddr == 0x1b) {
                            if (first == null) {
                                first = v;
                                Debug.WriteLine($"Found first 1b at offset {v.CompiledOffset:X2}");
                            } else if (v.Offset == 0x0be8 || v.Offset == 0x0fd5) {
                                Debug.WriteLine($"Set value of {v.Offset:X2} to {first.CompiledOffset:X2}");
                                v.VarValue = first.CompiledOffset;
                            }
                        }
                    }
                }
            }

            var result =
                Commands.Aggregate(Enumerable.Empty<byte>(), (acc, x) => (acc.Concat(x.CompiledActionData))).ToArray();
            var savePath = Path.Combine(saveDir, Path.GetFileName(FileName));
            if (File.Exists(savePath)) File.Delete(savePath);
            var prefix = Commands[0].Uint16Bytes(Offset);
            foreach (var r in Refs) {
                var cmd = FindCommand(r);
                if (cmd == null) {
                    Debug.WriteLine("Can't find original offset for start reference {0:X4}", r);
                    return false;
                }
                prefix = cmd.ArrayAppend(prefix, cmd.CompiledOffset);
            }
            File.WriteAllBytes(savePath, prefix.Concat(result).ToArray());
            return true;
        }

        public void TryLoadTranslation(TranslationRow translation, bool checkDate) {
            for (var cmd_i = 0; cmd_i < Commands.Length; cmd_i++) {
                var cmd1 = Commands[cmd_i];
                if (cmd1.Offset == translation.Offset && (! checkDate || cmd1.LastChanged < translation.LastChanged)) {
                    cmd1.LoadTranslation(translation);
                    break;
                }
                if (!cmd1.IsContainer) continue;

                for (var nested_i = 1; nested_i < cmd1.NestedCommands.Count; nested_i++) {
                    var nestedCmd = cmd1.NestedCommands[nested_i] as OutputText;

                    if (nestedCmd.Offset != translation.Offset) continue;

                    nestedCmd.IsVerified = translation.IsVerified;
                    //cmd1.Translation += "\r\n" + cmd.Translation;
                    (cmd1 as OutputText)?.AppendTranslation(translation);
                    break;
                }
            }
        }
    }
}