﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ScenarioEditor
{
    public class CommandJump : Command {
        public byte JumpVar { get; protected set; }
        public CommandJump(byte cmd, FileReader reader) : base(cmd, reader) {
        }
    }
    public class ConditionalJump : CommandJump
    {
        private string jumpCondition;
        private byte firstVar;
        private byte secondVar;

        public ConditionalJump(byte cmd, FileReader reader) : base(cmd, reader) {
            switch (cmd) {
                case 0x00:
                    jumpCondition = "eq";
                    break;
                case 0x01:
                    jumpCondition = "ne";
                    break;
                case 0x02:
                    jumpCondition = "le";
                    break;
                case 0x03:
                    jumpCondition = "ge";
                    break;
                case 0x04:
                    jumpCondition = "lt";
                    break;
                case 0x05:
                    jumpCondition = "gt";
                    break;
            }
            firstVar = reader.ReadByte();
            secondVar = reader.ReadByte();
            JumpVar = reader.ReadByte();
            this.IsText = false;
            IsJump = true;
            ActionData = new[] {firstVar, secondVar, JumpVar};
        }

        public override string ToString() {
            return String.Format("[{0:X4}]\tif ${1:X2} {2} ${3:X2} then goto ${4:X2}", Offset, firstVar, jumpCondition, secondVar, JumpVar);
        }


    }

    public class AlwaysJump : CommandJump
    {
        public AlwaysJump(byte cmd, FileReader reader) : base(cmd, reader) {
            this.IsText = false;
            JumpVar = reader.ReadByte();
            IsJump = true;
            ActionData = new[] {JumpVar};
        }

        public override string ToString() {
            return String.Format("[{0:X4}]\tgoto ${1:X2}", Offset, JumpVar);
        }
    }
}
