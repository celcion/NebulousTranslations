﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.VisualStyles;

namespace ImageParser
{
    public partial class Form1 : Form {
        private string inPath = "";
        private string outPath = "";
        private string compilePath = "";
        private string settingsPath;

        public Form1() {
            InitializeComponent();
        }

        private void Form1_Shown(object sender, EventArgs e) {
            var user_dir = Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);
            settingsPath = Path.Combine(user_dir, "macross_pic.txt");
            if (File.Exists(settingsPath)) {
                var strings = File.ReadAllLines(settingsPath);
                bOpenDir.ToolTipText = "Open directory (" + strings[0] + ")";
                inPath = strings[0];
                LoadFiles(strings[0]);
                if (strings.Length > 1) {
                    outPath = strings[1];
                    bExportBmp.ToolTipText =
                    $"Export PNG to {outPath} (press SHIFT to choose folder; press ALT to export all files)";
                }
                if (strings.Length > 2) {
                    compilePath = strings[2];
                    bExportBmp.ToolTipText = $"Compile OZM to {compilePath} (press SHIFT to choose folder)";
                }
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            File.WriteAllLines(settingsPath, new string[] { inPath, outPath, compilePath });
        }

        private void LoadFiles(string path) {
            var files = Directory.GetFiles(inPath, "*.OZM", SearchOption.AllDirectories);
            lbFiles.Items.Clear();
            foreach (var file in files) {
                lbFiles.Items.Add(new PicFile(file));
            }
        }

        private void lbFiles_SelectedIndexChanged(object sender, EventArgs e) {
            var file = (PicFile)lbFiles.SelectedItem;
            if (file == null) return;
            parseFile(file);
        }

        private void parseFile(PicFile file) {
            new Parser().ParseFile(file.FullName).Set(this);
        }

        private void bOpenDir_Click(object sender, EventArgs e) {
            var browser = new FolderBrowserDialog { Description = "Open folder containing BIN files" };
            if (browser.ShowDialog() == DialogResult.OK) {
                inPath = browser.SelectedPath;
                bOpenDir.ToolTipText = $"Open directory ({inPath})";
                LoadFiles(inPath);
            }
        }

        private PicFile SelectedFile() {
            return (PicFile)lbFiles.SelectedItem;
        }

        private void bExportBmp_Click(object sender, EventArgs e) {
            if ((ModifierKeys & Keys.Shift) != 0 || string.IsNullOrEmpty(outPath)) {
                if (!ChooseExportFolder()) return;
            }
            if ((ModifierKeys & Keys.Alt) != 0) {
                foreach (PicFile f in lbFiles.Items) {
                    var p = new Parser().ParseFile(f.FullName);
                    p.Bitmap.Save(Path.Combine(outPath, f.Fname.Replace(".OZM", ".PNG")), ImageFormat.Png);
                }
            } else {
                var f = SelectedFile();
                if (f == null) return;
                pictureBox1.Image.Save(Path.Combine(outPath, f.Fname.Replace(".OZM", ".PNG")), ImageFormat.Png);
            }
        }

        private bool ChooseExportFolder() {
            var browser = new FolderBrowserDialog { Description = "Open folder for saving PNG files" };
            if (browser.ShowDialog() == DialogResult.OK) {
                outPath = browser.SelectedPath;
                bExportBmp.ToolTipText =
                    $"Export PNG to {outPath} (press SHIFT to choose folder; press ALT to export all files)";
                return true;
            }
            return false;
        }

        private bool ChooseCompileFolder() {
            var browser = new FolderBrowserDialog { Description = "Open folder for saving compiled OZM files" };
            if (browser.ShowDialog() == DialogResult.OK) {
                compilePath = browser.SelectedPath;
                bExportBmp.ToolTipText = $"Compile OZM to {compilePath} (press SHIFT to choose folder)";
                return true;
            }
            return false;
        }

        private void bCompile_Click(object sender, EventArgs e) {
            if ((ModifierKeys & Keys.Shift) != 0 || string.IsNullOrEmpty(compilePath)) {
                if (!ChooseCompileFolder()) return;
            }
            if (SelectedFile() == null) {
                return;
            }
            if ((ModifierKeys & Keys.Alt) != 0) {
                foreach (PicFile f in lbFiles.Items) {
                    parseFile(f);
                    new Parser().Compile(compilePath, pictureBox1.Image, f);
                }
            } else {
                new Parser().Compile(compilePath, pictureBox1.Image, SelectedFile());
            }
        }

        private void bImportPNG_Click(object sender, EventArgs e) {
            if (SelectedFile() == null) {
                return;
            }
            var dialog = new OpenFileDialog {
                Filter = "PNG files (*.png)|*.png|All files (*.*)|*.*",
                FilterIndex = 0,
                DefaultExt = "png"
            };
            if (dialog.ShowDialog() == DialogResult.OK) {
                pictureBox1.Image = new Bitmap(dialog.FileName);
            }
        }
    }
}
