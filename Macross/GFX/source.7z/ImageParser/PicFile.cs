﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageParser
{
    class PicFile
    {
        public string Fname { get; set; }
        public string FullName { get; set; }
        public PicFile(string path) {
            FullName = path;
            Fname = new FileInfo(path).Name;
        }

        public override string ToString() {
            return Fname;
        }
    }
}
