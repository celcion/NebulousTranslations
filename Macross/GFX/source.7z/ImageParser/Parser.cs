﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ImageParser
{
    internal class Parser
    {
        private Color[] colorCodes;
        public Bitmap Bitmap { get; set; }
        static Dictionary<string, byte[]> cache = new Dictionary<string, byte[]>();
        private Color fakeWhite = Color.FromArgb(254, 254, 254);
        private Color fakeBlack = Color.FromArgb(1, 1, 1);

        private void readPalette(string file) {
            var data = new byte[58];
            File.OpenRead(file).Read(data, 0, 58);
            this.colorCodes = new Color[16];
            for (var i = 0; i < 16; i++) {
                var offset = 9 + i * 3;
                var red = (data[offset] << 4) + data[offset];
                var green = (data[offset + 1] << 4) + data[offset + 1];
                var blue = (data[offset + 2] << 4) + data[offset + 2];
                colorCodes[i] = Color.FromArgb(red, green, blue);
            }
        }

        public Parser ParseFile(string file) {
            var fname = new FileInfo(file).Name;
            var data = File.ReadAllBytes(file);
            var xPixel = 0;
            var yPixel = 0;
            const int startOffset = 0x3a;
            var stopOffset = data.Length;
            var horizontalBytes = (data[3] << 8) + data[2];
            var verticalLines = (data[5] << 8) + data[4];
            this.Bitmap = new Bitmap(horizontalBytes * 8, verticalLines);

            readPalette(file);

            var currentOffset = startOffset;
            //var picture = new byte[horizontalBytes * 8 * verticalLines * 1000];
            var picture = new byte[horizontalBytes * verticalLines * 4];
            //var picture = new List<byte>();
            var iPic = 0;
            while (currentOffset < stopOffset) {
                if (data[currentOffset] == 0) {
                    if (data[currentOffset + 1] == 7) {
                        var bytes = new byte[2];
                        bytes[0] = data[currentOffset + 2];
                        bytes[1] = data[currentOffset + 3];
                        var repeatCount = (data[currentOffset + 5] << 8) + data[currentOffset + 4];
                        var idx = 0;
                        for (var i = 0; i < repeatCount; i++) {
                            picture[iPic++] = bytes[idx];
                            idx = idx ^ 1;
                        }
                        currentOffset += 6;
                    } else if (data[currentOffset + 1] == 6) {
                        var bdata = data[currentOffset + 2];
                        var repeatCount = (data[currentOffset + 4] << 8) + data[currentOffset + 3];
                        for (var i = 0; i < repeatCount; i++) {
                            picture[iPic++] = bdata;
                        }
                        currentOffset += 5;
                    } else if (data[currentOffset + 1] > 0 && data[currentOffset + 1] < 6) {
                        var repeatCount = data[currentOffset + 1];
                        for (var i = 0; i < repeatCount; i++) {
                            picture[iPic++] = 0;
                        }
                        currentOffset += 2;
                    }
                } else {
                    picture[iPic++] = data[currentOffset++];
                }
            }
            Debug.WriteLine(iPic);
            Debug.WriteLine($"fname: {fname}, hb: {horizontalBytes}, vl: {verticalLines}, i: {iPic}");
            var bppSize = horizontalBytes * verticalLines;
            //Debug.WriteLine(BitConverter.ToString(picture));
            cache[fname] = picture;
            for (var i = 0; i < bppSize; i++) {
                var pixelLine = new int[8];
                var curByte = i;
                var layers = new int[4];
                for (var ii = 0; ii < 4; ii++) {
                    layers[ii] = (int)picture[curByte + (bppSize * ii)];
                }
                for (var ii = 0; ii < 8; ii++) {
                    var mask = 1 << ii;
                    for (var iii = 0; iii < 4; iii++) {
                        pixelLine[ii] = pixelLine[ii] | (((layers[iii] & mask) >> ii) << iii);
                    }
                }

                for (var ii = 0; ii < 8; ii++) {
                    var idx = pixelLine[7 - ii];
                    var color = colorCodes[idx];
                    if (CompareColors(color, Color.Black) && idx != 0) {
                        color = fakeBlack;
                        Debug.WriteLine("Replace BLACK color");
                    } else if (CompareColors(color, Color.White) && idx != 15) {
                        color = fakeWhite;
                        Debug.WriteLine("Replace WHITE color");
                    }
                    Bitmap.SetPixel(xPixel + ii, yPixel, color);
                }
                yPixel++;
                if (yPixel >= verticalLines) {
                    yPixel = 0;
                    xPixel += 8;
                }
            }
            return this;
        }

        private bool CompareColors(Color c1, Color c2) {
            return c1.R == c2.R && c1.G == c2.G && c1.B == c2.B;
        }

        public void Set(Form1 form) {
            form.pictureBox1.Image = Bitmap;
            form.pColor1.BackColor = colorCodes[0];
            form.l1R.Text = $"R: {colorCodes[0].R}";
            form.l1G.Text = $"G: {colorCodes[0].G}";
            form.l1B.Text = $"B: {colorCodes[0].B}";
            form.pColor2.BackColor = colorCodes[1];
            form.l2R.Text = $"R: {colorCodes[1].R}";
            form.l2G.Text = $"G: {colorCodes[1].G}";
            form.l2B.Text = $"B: {colorCodes[1].B}";
            form.pColor3.BackColor = colorCodes[2];
            form.l3R.Text = $"R: {colorCodes[2].R}";
            form.l3G.Text = $"G: {colorCodes[2].G}";
            form.l3B.Text = $"B: {colorCodes[2].B}";
            form.pColor4.BackColor = colorCodes[3];
            form.l4R.Text = $"R: {colorCodes[3].R}";
            form.l4G.Text = $"G: {colorCodes[3].G}";
            form.l4B.Text = $"B: {colorCodes[3].B}";
            form.pColor5.BackColor = colorCodes[4];
            form.l5R.Text = $"R: {colorCodes[4].R}";
            form.l5G.Text = $"G: {colorCodes[4].G}";
            form.l5B.Text = $"B: {colorCodes[4].B}";
            form.pColor6.BackColor = colorCodes[5];
            form.l6R.Text = $"R: {colorCodes[5].R}";
            form.l6G.Text = $"G: {colorCodes[5].G}";
            form.l6B.Text = $"B: {colorCodes[5].B}";
            form.pColor7.BackColor = colorCodes[6];
            form.l7R.Text = $"R: {colorCodes[6].R}";
            form.l7G.Text = $"G: {colorCodes[6].G}";
            form.l7B.Text = $"B: {colorCodes[6].B}";
            form.pColor8.BackColor = colorCodes[7];
            form.l8R.Text = $"R: {colorCodes[7].R}";
            form.l8G.Text = $"G: {colorCodes[7].G}";
            form.l8B.Text = $"B: {colorCodes[7].B}";
            form.pColor9.BackColor = colorCodes[8];
            form.l9R.Text = $"R: {colorCodes[8].R}";
            form.l9G.Text = $"G: {colorCodes[8].G}";
            form.l9B.Text = $"B: {colorCodes[8].B}";
            form.pColor10.BackColor = colorCodes[9];
            form.l10R.Text = $"R: {colorCodes[9].R}";
            form.l10G.Text = $"G: {colorCodes[9].G}";
            form.l10B.Text = $"B: {colorCodes[9].B}";
            form.pColor11.BackColor = colorCodes[10];
            form.l11R.Text = $"R: {colorCodes[10].R}";
            form.l11G.Text = $"G: {colorCodes[10].G}";
            form.l11B.Text = $"B: {colorCodes[10].B}";
            form.pColor12.BackColor = colorCodes[11];
            form.l12R.Text = $"R: {colorCodes[11].R}";
            form.l12G.Text = $"G: {colorCodes[11].G}";
            form.l12B.Text = $"B: {colorCodes[11].B}";
            form.pColor13.BackColor = colorCodes[12];
            form.l13R.Text = $"R: {colorCodes[12].R}";
            form.l13G.Text = $"G: {colorCodes[12].G}";
            form.l13B.Text = $"B: {colorCodes[12].B}";
            form.pColor14.BackColor = colorCodes[13];
            form.l14R.Text = $"R: {colorCodes[13].R}";
            form.l14G.Text = $"G: {colorCodes[13].G}";
            form.l14B.Text = $"B: {colorCodes[13].B}";
            form.pColor15.BackColor = colorCodes[14];
            form.l15R.Text = $"R: {colorCodes[14].R}";
            form.l15G.Text = $"G: {colorCodes[14].G}";
            form.l15B.Text = $"B: {colorCodes[14].B}";
            form.pColor16.BackColor = colorCodes[15];
            form.l16R.Text = $"R: {colorCodes[15].R}";
            form.l16G.Text = $"G: {colorCodes[15].G}";
            form.l16B.Text = $"B: {colorCodes[15].B}";
            form.Refresh();
        }

        public void Compile(string compilePath, Image img, PicFile file) {
            this.Bitmap = new Bitmap(img);
            readPalette(file.FullName);
            var pic = FlattenImage();
            if (!cache[file.Fname].SequenceEqual(pic)) {
                MessageBox.Show($"Warning: {file.Fname} differs!");
                //File.WriteAllBytes(@"D:\Translations\Macross\ImageParser\ImageParser\bin\Debug\orig_" + file.Fname, cache[file.Fname]);
                //File.WriteAllBytes(@"D:\Translations\Macross\ImageParser\ImageParser\bin\Debug\parsed_" + file.Fname, pic);
            }
            var pack = new byte[pic.Length * 2]; // на всякий случай, вдруг алгоритм кодирования, наоборот, раздует размер
            var currentPx = 0;
            var packPx = 0;
            var horizontalBytes = this.Bitmap.Width / 8;
            var verticalLines = this.Bitmap.Height;
            var bppSize = horizontalBytes * verticalLines;
            //var orig_pic = pic;
            while (currentPx < pic.Length) {
                // попытаемся найти паттерн
                var repeatCount = 0;
                if (currentPx + 1 < pic.Length && pic[currentPx] != pic[currentPx + 1] && pic[currentPx] > 0 && pic[currentPx + 1] > 0 && ((currentPx + 1) % bppSize > 0)) {
                    var bytes = new byte[2];
                    bytes[0] = pic[currentPx];
                    bytes[1] = pic[currentPx + 1];
                    repeatCount = 2;
                    var idx = 0;
                    for (var i = currentPx + 2; i < pic.Length; i++) {
                        if (i % bppSize == 0) {
                            break;
                        }
                        if (pic[i] == bytes[idx]) {
                            repeatCount++;
                            idx = idx ^ 1;
                        } else {
                            break;
                        }
                    }
                    if (repeatCount >= 6) { // нашли паттерн
                        pack[packPx++] = 0;
                        pack[packPx++] = 7;
                        pack[packPx++] = bytes[0];
                        pack[packPx++] = bytes[1];
                        pack[packPx++] = (byte)(repeatCount & 0x000000FF);
                        pack[packPx++] = (byte)(repeatCount >> 8);
                        currentPx += repeatCount;
                        continue;
                    }
                }
                var b = pic[currentPx];
                repeatCount = 1;
                for (var i = currentPx + 1; i < pic.Length; i++) {
                    if (i % bppSize == 0) {
                        break;
                    }
                    if (pic[i] == b) {
                        repeatCount++;
                    } else {
                        break;
                    }
                }
                if (b == 0 && repeatCount < 6) {
                    // для нуля нужно даже 1 раз повтор писать
                    currentPx += repeatCount;
                    pack[packPx++] = 0;
                    pack[packPx++] = (byte) repeatCount;
                    continue;
                }
                if (b == 0 || repeatCount > 4) {
                    currentPx += repeatCount;
                    if (repeatCount > 0) {
                        pack[packPx++] = 0;
                        pack[packPx++] = 6;
                        pack[packPx++] = b;
                        pack[packPx++] = (byte)(repeatCount & 0x000000FF);
                        pack[packPx++] = (byte)(repeatCount >> 8);
                    }
                    continue;
                }
                pack[packPx++] = b;
                currentPx++;
            }
            /*for (var layer = 0; layer < 4; layer++) {
                pic = new byte[bppSize];
                Array.Copy(orig_pic, bppSize * layer, pic, 0, bppSize);
                while (currentPx < pic.Length) {
                    // попытаемся найти паттерн
                    var repeatCount = 0;
                    if (currentPx + 1 < pic.Length && pic[currentPx] != pic[currentPx + 1] && pic[currentPx] > 0 &&
                        pic[currentPx + 1] > 0) {
                        var bytes = new byte[2];
                        bytes[0] = pic[currentPx];
                        bytes[1] = pic[currentPx + 1];
                        repeatCount = 2;
                        var idx = 0;
                        for (var i = currentPx + 2; i < pic.Length; i++) {
                            if (pic[i] == bytes[idx]) {
                                repeatCount++;
                                idx = idx ^ 1;
                            } else {
                                break;
                            }
                        }
                        if (repeatCount >= 6) {
                            // нашли паттерн
                            pack[packPx++] = 0;
                            pack[packPx++] = 7;
                            pack[packPx++] = bytes[0];
                            pack[packPx++] = bytes[1];
                            pack[packPx++] = (byte) (repeatCount & 0x000000FF);
                            pack[packPx++] = (byte) (repeatCount >> 8);
                            currentPx += repeatCount;
                            continue;
                        }
                    }
                    var b = pic[currentPx];
                    repeatCount = 1;
                    for (var i = currentPx + 1; i < pic.Length; i++) {
                        if (pic[i] == b) {
                            repeatCount++;
                        } else {
                            break;
                        }
                    }
                    if (b == 0 && repeatCount < 6) {
                        // для нуля нужно даже 1 раз повтор писать
                        currentPx += repeatCount;
                        pack[packPx++] = 0;
                        pack[packPx++] = (byte) repeatCount;
                        continue;
                    }
                    if (b == 0 || repeatCount > 4) {
                        currentPx += repeatCount;
                        if (repeatCount > 0) {
                            pack[packPx++] = 0;
                            pack[packPx++] = 6;
                            pack[packPx++] = b;
                            pack[packPx++] = (byte) (repeatCount & 0x000000FF);
                            pack[packPx++] = (byte) (repeatCount >> 8);
                        }
                        continue;
                    }
                    pack[packPx++] = b;
                    currentPx++;
                }
            }*/
            var ofile = Path.Combine(compilePath, file.Fname);
            if (File.Exists(ofile)) {
                File.Delete(ofile);
            }
            using (var fh = File.OpenWrite(ofile)) {
                var data = new byte[0x3a];
                File.OpenRead(file.FullName).Read(data, 0, 0x3a);
                fh.Write(data, 0, 0x3a);
                fh.Write(pack, 0, packPx);
            }
        }

        private byte[] FlattenImage() {
            var bmp = this.Bitmap;
            var horizontalBytes = bmp.Width / 8;
            var verticalLines = bmp.Height;
            var pic = new byte[horizontalBytes * verticalLines * 4];
            var iPic = 0;
            var bppSize = horizontalBytes * verticalLines;
            var yPixel = 0;
            var xPixel = 0;
            var colours = colorCodes.ToArray();
            for (var i = 1; i < 15; i++) {
                if (CompareColors(colours[i], Color.White)) {
                    colours[i] = fakeWhite;
                } else if (CompareColors(colours[i], Color.Black)) {
                    colours[i] = fakeBlack;
                }
            }
            for (var i = 0; i < bppSize; i++) {
                var pixelLine = new int[8];
                var curByte = i;
                var layers = new int[4];
                for (var ii = 0; ii < 8; ii++) {
                    var colour = bmp.GetPixel(xPixel + ii, yPixel);
                    var idx = 0;
                    
                    for (; idx < 16; idx++) {
                        if (CompareColors(colours[idx], colour)) {
                            break;
                        }
                    }
                    if (CompareColors(colour, fakeWhite) && idx != 15) {
                        Debug.WriteLine("Restore WHITE colour, {0}", idx);
                    } else if (CompareColors(colour, fakeBlack) && idx != 0) {
                        Debug.WriteLine("Restore BLACK colour, {0}", idx);
                    }
                    pixelLine[7 - ii] = idx;
                }
                for (var ii = 0; ii < 8; ii++) {
                    var mask = 1 << ii;
                    for (var iii = 0; iii < 4; iii++) {
                        if ((pixelLine[ii] & (1 << iii)) > 0) {
                            layers[iii] = layers[iii] | mask;
                        }
                    }
                }
                for (var ii = 0; ii < 4; ii++) {
                    pic[curByte + (bppSize * ii)] = (byte) layers[ii];
                }
                yPixel++;
                if (yPixel >= verticalLines) {
                    yPixel = 0;
                    xPixel += 8;
                }
            }
            return pic;
        }
    }
}
