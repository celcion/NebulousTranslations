﻿namespace ImageParser
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tStatusCurrentFile = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.bOpenDir = new System.Windows.Forms.ToolStripButton();
            this.bExportBmp = new System.Windows.Forms.ToolStripButton();
            this.bCompile = new System.Windows.Forms.ToolStripButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.lbFiles = new System.Windows.Forms.ListBox();
            this.splitContainer2 = new System.Windows.Forms.SplitContainer();
            this.l16B = new System.Windows.Forms.Label();
            this.l16G = new System.Windows.Forms.Label();
            this.l16R = new System.Windows.Forms.Label();
            this.l15B = new System.Windows.Forms.Label();
            this.l15G = new System.Windows.Forms.Label();
            this.l15R = new System.Windows.Forms.Label();
            this.l14B = new System.Windows.Forms.Label();
            this.l14G = new System.Windows.Forms.Label();
            this.l14R = new System.Windows.Forms.Label();
            this.l13B = new System.Windows.Forms.Label();
            this.l13G = new System.Windows.Forms.Label();
            this.l13R = new System.Windows.Forms.Label();
            this.l12B = new System.Windows.Forms.Label();
            this.l12G = new System.Windows.Forms.Label();
            this.l12R = new System.Windows.Forms.Label();
            this.l11B = new System.Windows.Forms.Label();
            this.l11G = new System.Windows.Forms.Label();
            this.l11R = new System.Windows.Forms.Label();
            this.l10B = new System.Windows.Forms.Label();
            this.l10G = new System.Windows.Forms.Label();
            this.l10R = new System.Windows.Forms.Label();
            this.l9B = new System.Windows.Forms.Label();
            this.l9G = new System.Windows.Forms.Label();
            this.l9R = new System.Windows.Forms.Label();
            this.l8B = new System.Windows.Forms.Label();
            this.l8G = new System.Windows.Forms.Label();
            this.l8R = new System.Windows.Forms.Label();
            this.l7B = new System.Windows.Forms.Label();
            this.l7G = new System.Windows.Forms.Label();
            this.l7R = new System.Windows.Forms.Label();
            this.l6B = new System.Windows.Forms.Label();
            this.l6G = new System.Windows.Forms.Label();
            this.l6R = new System.Windows.Forms.Label();
            this.l5B = new System.Windows.Forms.Label();
            this.l5G = new System.Windows.Forms.Label();
            this.l5R = new System.Windows.Forms.Label();
            this.l4B = new System.Windows.Forms.Label();
            this.l4G = new System.Windows.Forms.Label();
            this.l4R = new System.Windows.Forms.Label();
            this.l3B = new System.Windows.Forms.Label();
            this.l3G = new System.Windows.Forms.Label();
            this.l3R = new System.Windows.Forms.Label();
            this.l2B = new System.Windows.Forms.Label();
            this.l2G = new System.Windows.Forms.Label();
            this.l2R = new System.Windows.Forms.Label();
            this.l1B = new System.Windows.Forms.Label();
            this.l1G = new System.Windows.Forms.Label();
            this.l1R = new System.Windows.Forms.Label();
            this.pColor16 = new System.Windows.Forms.PictureBox();
            this.pColor15 = new System.Windows.Forms.PictureBox();
            this.pColor14 = new System.Windows.Forms.PictureBox();
            this.pColor13 = new System.Windows.Forms.PictureBox();
            this.pColor12 = new System.Windows.Forms.PictureBox();
            this.pColor11 = new System.Windows.Forms.PictureBox();
            this.pColor10 = new System.Windows.Forms.PictureBox();
            this.pColor9 = new System.Windows.Forms.PictureBox();
            this.pColor8 = new System.Windows.Forms.PictureBox();
            this.pColor7 = new System.Windows.Forms.PictureBox();
            this.pColor6 = new System.Windows.Forms.PictureBox();
            this.pColor5 = new System.Windows.Forms.PictureBox();
            this.pColor4 = new System.Windows.Forms.PictureBox();
            this.pColor3 = new System.Windows.Forms.PictureBox();
            this.pColor2 = new System.Windows.Forms.PictureBox();
            this.pColor1 = new System.Windows.Forms.PictureBox();
            this.bImportPNG = new System.Windows.Forms.ToolStripButton();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).BeginInit();
            this.splitContainer2.Panel1.SuspendLayout();
            this.splitContainer2.Panel2.SuspendLayout();
            this.splitContainer2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pColor16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(640, 480);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tStatusCurrentFile});
            this.statusStrip1.Location = new System.Drawing.Point(0, 637);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(871, 22);
            this.statusStrip1.TabIndex = 2;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tStatusCurrentFile
            // 
            this.tStatusCurrentFile.Name = "tStatusCurrentFile";
            this.tStatusCurrentFile.Size = new System.Drawing.Size(0, 17);
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bOpenDir,
            this.bExportBmp,
            this.bCompile,
            this.bImportPNG});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(871, 25);
            this.toolStrip1.TabIndex = 3;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // bOpenDir
            // 
            this.bOpenDir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bOpenDir.Image = ((System.Drawing.Image)(resources.GetObject("bOpenDir.Image")));
            this.bOpenDir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bOpenDir.Name = "bOpenDir";
            this.bOpenDir.Size = new System.Drawing.Size(40, 22);
            this.bOpenDir.Text = "Open";
            this.bOpenDir.ToolTipText = "Open directory";
            this.bOpenDir.Click += new System.EventHandler(this.bOpenDir_Click);
            // 
            // bExportBmp
            // 
            this.bExportBmp.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bExportBmp.Image = ((System.Drawing.Image)(resources.GetObject("bExportBmp.Image")));
            this.bExportBmp.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bExportBmp.Name = "bExportBmp";
            this.bExportBmp.Size = new System.Drawing.Size(71, 22);
            this.bExportBmp.Text = "Export PNG";
            this.bExportBmp.ToolTipText = "Export PNG (press SHIFT to choose folder; press ALT to export all files)";
            this.bExportBmp.Click += new System.EventHandler(this.bExportBmp_Click);
            // 
            // bCompile
            // 
            this.bCompile.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bCompile.Image = ((System.Drawing.Image)(resources.GetObject("bCompile.Image")));
            this.bCompile.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bCompile.Name = "bCompile";
            this.bCompile.Size = new System.Drawing.Size(56, 22);
            this.bCompile.Text = "Compile";
            this.bCompile.ToolTipText = "Compile (press SHIFT to choose folder)";
            this.bCompile.Click += new System.EventHandler(this.bCompile_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.Location = new System.Drawing.Point(0, 25);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.lbFiles);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.splitContainer2);
            this.splitContainer1.Panel2MinSize = 640;
            this.splitContainer1.Size = new System.Drawing.Size(871, 612);
            this.splitContainer1.SplitterDistance = 220;
            this.splitContainer1.TabIndex = 4;
            // 
            // lbFiles
            // 
            this.lbFiles.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbFiles.FormattingEnabled = true;
            this.lbFiles.Location = new System.Drawing.Point(0, 0);
            this.lbFiles.Name = "lbFiles";
            this.lbFiles.Size = new System.Drawing.Size(220, 612);
            this.lbFiles.TabIndex = 0;
            this.lbFiles.SelectedIndexChanged += new System.EventHandler(this.lbFiles_SelectedIndexChanged);
            // 
            // splitContainer2
            // 
            this.splitContainer2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer2.Location = new System.Drawing.Point(0, 0);
            this.splitContainer2.Name = "splitContainer2";
            this.splitContainer2.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer2.Panel1
            // 
            this.splitContainer2.Panel1.Controls.Add(this.pictureBox1);
            // 
            // splitContainer2.Panel2
            // 
            this.splitContainer2.Panel2.Controls.Add(this.l16B);
            this.splitContainer2.Panel2.Controls.Add(this.l16G);
            this.splitContainer2.Panel2.Controls.Add(this.l16R);
            this.splitContainer2.Panel2.Controls.Add(this.l15B);
            this.splitContainer2.Panel2.Controls.Add(this.l15G);
            this.splitContainer2.Panel2.Controls.Add(this.l15R);
            this.splitContainer2.Panel2.Controls.Add(this.l14B);
            this.splitContainer2.Panel2.Controls.Add(this.l14G);
            this.splitContainer2.Panel2.Controls.Add(this.l14R);
            this.splitContainer2.Panel2.Controls.Add(this.l13B);
            this.splitContainer2.Panel2.Controls.Add(this.l13G);
            this.splitContainer2.Panel2.Controls.Add(this.l13R);
            this.splitContainer2.Panel2.Controls.Add(this.l12B);
            this.splitContainer2.Panel2.Controls.Add(this.l12G);
            this.splitContainer2.Panel2.Controls.Add(this.l12R);
            this.splitContainer2.Panel2.Controls.Add(this.l11B);
            this.splitContainer2.Panel2.Controls.Add(this.l11G);
            this.splitContainer2.Panel2.Controls.Add(this.l11R);
            this.splitContainer2.Panel2.Controls.Add(this.l10B);
            this.splitContainer2.Panel2.Controls.Add(this.l10G);
            this.splitContainer2.Panel2.Controls.Add(this.l10R);
            this.splitContainer2.Panel2.Controls.Add(this.l9B);
            this.splitContainer2.Panel2.Controls.Add(this.l9G);
            this.splitContainer2.Panel2.Controls.Add(this.l9R);
            this.splitContainer2.Panel2.Controls.Add(this.l8B);
            this.splitContainer2.Panel2.Controls.Add(this.l8G);
            this.splitContainer2.Panel2.Controls.Add(this.l8R);
            this.splitContainer2.Panel2.Controls.Add(this.l7B);
            this.splitContainer2.Panel2.Controls.Add(this.l7G);
            this.splitContainer2.Panel2.Controls.Add(this.l7R);
            this.splitContainer2.Panel2.Controls.Add(this.l6B);
            this.splitContainer2.Panel2.Controls.Add(this.l6G);
            this.splitContainer2.Panel2.Controls.Add(this.l6R);
            this.splitContainer2.Panel2.Controls.Add(this.l5B);
            this.splitContainer2.Panel2.Controls.Add(this.l5G);
            this.splitContainer2.Panel2.Controls.Add(this.l5R);
            this.splitContainer2.Panel2.Controls.Add(this.l4B);
            this.splitContainer2.Panel2.Controls.Add(this.l4G);
            this.splitContainer2.Panel2.Controls.Add(this.l4R);
            this.splitContainer2.Panel2.Controls.Add(this.l3B);
            this.splitContainer2.Panel2.Controls.Add(this.l3G);
            this.splitContainer2.Panel2.Controls.Add(this.l3R);
            this.splitContainer2.Panel2.Controls.Add(this.l2B);
            this.splitContainer2.Panel2.Controls.Add(this.l2G);
            this.splitContainer2.Panel2.Controls.Add(this.l2R);
            this.splitContainer2.Panel2.Controls.Add(this.l1B);
            this.splitContainer2.Panel2.Controls.Add(this.l1G);
            this.splitContainer2.Panel2.Controls.Add(this.l1R);
            this.splitContainer2.Panel2.Controls.Add(this.pColor16);
            this.splitContainer2.Panel2.Controls.Add(this.pColor15);
            this.splitContainer2.Panel2.Controls.Add(this.pColor14);
            this.splitContainer2.Panel2.Controls.Add(this.pColor13);
            this.splitContainer2.Panel2.Controls.Add(this.pColor12);
            this.splitContainer2.Panel2.Controls.Add(this.pColor11);
            this.splitContainer2.Panel2.Controls.Add(this.pColor10);
            this.splitContainer2.Panel2.Controls.Add(this.pColor9);
            this.splitContainer2.Panel2.Controls.Add(this.pColor8);
            this.splitContainer2.Panel2.Controls.Add(this.pColor7);
            this.splitContainer2.Panel2.Controls.Add(this.pColor6);
            this.splitContainer2.Panel2.Controls.Add(this.pColor5);
            this.splitContainer2.Panel2.Controls.Add(this.pColor4);
            this.splitContainer2.Panel2.Controls.Add(this.pColor3);
            this.splitContainer2.Panel2.Controls.Add(this.pColor2);
            this.splitContainer2.Panel2.Controls.Add(this.pColor1);
            this.splitContainer2.Size = new System.Drawing.Size(647, 612);
            this.splitContainer2.SplitterDistance = 483;
            this.splitContainer2.TabIndex = 2;
            // 
            // l16B
            // 
            this.l16B.AutoSize = true;
            this.l16B.Location = new System.Drawing.Point(534, 87);
            this.l16B.Name = "l16B";
            this.l16B.Size = new System.Drawing.Size(38, 13);
            this.l16B.TabIndex = 63;
            this.l16B.Text = "B: 255";
            // 
            // l16G
            // 
            this.l16G.AutoSize = true;
            this.l16G.Location = new System.Drawing.Point(534, 75);
            this.l16G.Name = "l16G";
            this.l16G.Size = new System.Drawing.Size(39, 13);
            this.l16G.TabIndex = 62;
            this.l16G.Text = "G: 255";
            // 
            // l16R
            // 
            this.l16R.AutoSize = true;
            this.l16R.Location = new System.Drawing.Point(534, 62);
            this.l16R.Name = "l16R";
            this.l16R.Size = new System.Drawing.Size(39, 13);
            this.l16R.TabIndex = 61;
            this.l16R.Text = "R: 255";
            // 
            // l15B
            // 
            this.l15B.AutoSize = true;
            this.l15B.Location = new System.Drawing.Point(463, 87);
            this.l15B.Name = "l15B";
            this.l15B.Size = new System.Drawing.Size(38, 13);
            this.l15B.TabIndex = 60;
            this.l15B.Text = "B: 255";
            // 
            // l15G
            // 
            this.l15G.AutoSize = true;
            this.l15G.Location = new System.Drawing.Point(463, 75);
            this.l15G.Name = "l15G";
            this.l15G.Size = new System.Drawing.Size(39, 13);
            this.l15G.TabIndex = 59;
            this.l15G.Text = "G: 255";
            // 
            // l15R
            // 
            this.l15R.AutoSize = true;
            this.l15R.Location = new System.Drawing.Point(463, 62);
            this.l15R.Name = "l15R";
            this.l15R.Size = new System.Drawing.Size(39, 13);
            this.l15R.TabIndex = 58;
            this.l15R.Text = "R: 255";
            // 
            // l14B
            // 
            this.l14B.AutoSize = true;
            this.l14B.Location = new System.Drawing.Point(392, 87);
            this.l14B.Name = "l14B";
            this.l14B.Size = new System.Drawing.Size(38, 13);
            this.l14B.TabIndex = 57;
            this.l14B.Text = "B: 255";
            // 
            // l14G
            // 
            this.l14G.AutoSize = true;
            this.l14G.Location = new System.Drawing.Point(392, 75);
            this.l14G.Name = "l14G";
            this.l14G.Size = new System.Drawing.Size(39, 13);
            this.l14G.TabIndex = 56;
            this.l14G.Text = "G: 255";
            // 
            // l14R
            // 
            this.l14R.AutoSize = true;
            this.l14R.Location = new System.Drawing.Point(392, 62);
            this.l14R.Name = "l14R";
            this.l14R.Size = new System.Drawing.Size(39, 13);
            this.l14R.TabIndex = 55;
            this.l14R.Text = "R: 255";
            // 
            // l13B
            // 
            this.l13B.AutoSize = true;
            this.l13B.Location = new System.Drawing.Point(320, 87);
            this.l13B.Name = "l13B";
            this.l13B.Size = new System.Drawing.Size(38, 13);
            this.l13B.TabIndex = 54;
            this.l13B.Text = "B: 255";
            // 
            // l13G
            // 
            this.l13G.AutoSize = true;
            this.l13G.Location = new System.Drawing.Point(320, 75);
            this.l13G.Name = "l13G";
            this.l13G.Size = new System.Drawing.Size(39, 13);
            this.l13G.TabIndex = 53;
            this.l13G.Text = "G: 255";
            // 
            // l13R
            // 
            this.l13R.AutoSize = true;
            this.l13R.Location = new System.Drawing.Point(320, 62);
            this.l13R.Name = "l13R";
            this.l13R.Size = new System.Drawing.Size(39, 13);
            this.l13R.TabIndex = 52;
            this.l13R.Text = "R: 255";
            // 
            // l12B
            // 
            this.l12B.AutoSize = true;
            this.l12B.Location = new System.Drawing.Point(250, 87);
            this.l12B.Name = "l12B";
            this.l12B.Size = new System.Drawing.Size(38, 13);
            this.l12B.TabIndex = 51;
            this.l12B.Text = "B: 255";
            // 
            // l12G
            // 
            this.l12G.AutoSize = true;
            this.l12G.Location = new System.Drawing.Point(250, 75);
            this.l12G.Name = "l12G";
            this.l12G.Size = new System.Drawing.Size(39, 13);
            this.l12G.TabIndex = 50;
            this.l12G.Text = "G: 255";
            // 
            // l12R
            // 
            this.l12R.AutoSize = true;
            this.l12R.Location = new System.Drawing.Point(250, 62);
            this.l12R.Name = "l12R";
            this.l12R.Size = new System.Drawing.Size(39, 13);
            this.l12R.TabIndex = 49;
            this.l12R.Text = "R: 255";
            // 
            // l11B
            // 
            this.l11B.AutoSize = true;
            this.l11B.Location = new System.Drawing.Point(180, 87);
            this.l11B.Name = "l11B";
            this.l11B.Size = new System.Drawing.Size(38, 13);
            this.l11B.TabIndex = 48;
            this.l11B.Text = "B: 255";
            // 
            // l11G
            // 
            this.l11G.AutoSize = true;
            this.l11G.Location = new System.Drawing.Point(180, 75);
            this.l11G.Name = "l11G";
            this.l11G.Size = new System.Drawing.Size(39, 13);
            this.l11G.TabIndex = 47;
            this.l11G.Text = "G: 255";
            // 
            // l11R
            // 
            this.l11R.AutoSize = true;
            this.l11R.Location = new System.Drawing.Point(180, 62);
            this.l11R.Name = "l11R";
            this.l11R.Size = new System.Drawing.Size(39, 13);
            this.l11R.TabIndex = 46;
            this.l11R.Text = "R: 255";
            // 
            // l10B
            // 
            this.l10B.AutoSize = true;
            this.l10B.Location = new System.Drawing.Point(108, 87);
            this.l10B.Name = "l10B";
            this.l10B.Size = new System.Drawing.Size(38, 13);
            this.l10B.TabIndex = 45;
            this.l10B.Text = "B: 255";
            // 
            // l10G
            // 
            this.l10G.AutoSize = true;
            this.l10G.Location = new System.Drawing.Point(108, 75);
            this.l10G.Name = "l10G";
            this.l10G.Size = new System.Drawing.Size(39, 13);
            this.l10G.TabIndex = 44;
            this.l10G.Text = "G: 255";
            // 
            // l10R
            // 
            this.l10R.AutoSize = true;
            this.l10R.Location = new System.Drawing.Point(108, 62);
            this.l10R.Name = "l10R";
            this.l10R.Size = new System.Drawing.Size(39, 13);
            this.l10R.TabIndex = 43;
            this.l10R.Text = "R: 255";
            // 
            // l9B
            // 
            this.l9B.AutoSize = true;
            this.l9B.Location = new System.Drawing.Point(36, 87);
            this.l9B.Name = "l9B";
            this.l9B.Size = new System.Drawing.Size(38, 13);
            this.l9B.TabIndex = 42;
            this.l9B.Text = "B: 255";
            // 
            // l9G
            // 
            this.l9G.AutoSize = true;
            this.l9G.Location = new System.Drawing.Point(36, 75);
            this.l9G.Name = "l9G";
            this.l9G.Size = new System.Drawing.Size(39, 13);
            this.l9G.TabIndex = 41;
            this.l9G.Text = "G: 255";
            // 
            // l9R
            // 
            this.l9R.AutoSize = true;
            this.l9R.Location = new System.Drawing.Point(36, 62);
            this.l9R.Name = "l9R";
            this.l9R.Size = new System.Drawing.Size(39, 13);
            this.l9R.TabIndex = 40;
            this.l9R.Text = "R: 255";
            // 
            // l8B
            // 
            this.l8B.AutoSize = true;
            this.l8B.Location = new System.Drawing.Point(534, 31);
            this.l8B.Name = "l8B";
            this.l8B.Size = new System.Drawing.Size(38, 13);
            this.l8B.TabIndex = 39;
            this.l8B.Text = "B: 255";
            // 
            // l8G
            // 
            this.l8G.AutoSize = true;
            this.l8G.Location = new System.Drawing.Point(534, 19);
            this.l8G.Name = "l8G";
            this.l8G.Size = new System.Drawing.Size(39, 13);
            this.l8G.TabIndex = 38;
            this.l8G.Text = "G: 255";
            // 
            // l8R
            // 
            this.l8R.AutoSize = true;
            this.l8R.Location = new System.Drawing.Point(534, 6);
            this.l8R.Name = "l8R";
            this.l8R.Size = new System.Drawing.Size(39, 13);
            this.l8R.TabIndex = 37;
            this.l8R.Text = "R: 255";
            // 
            // l7B
            // 
            this.l7B.AutoSize = true;
            this.l7B.Location = new System.Drawing.Point(463, 31);
            this.l7B.Name = "l7B";
            this.l7B.Size = new System.Drawing.Size(38, 13);
            this.l7B.TabIndex = 36;
            this.l7B.Text = "B: 255";
            // 
            // l7G
            // 
            this.l7G.AutoSize = true;
            this.l7G.Location = new System.Drawing.Point(463, 19);
            this.l7G.Name = "l7G";
            this.l7G.Size = new System.Drawing.Size(39, 13);
            this.l7G.TabIndex = 35;
            this.l7G.Text = "G: 255";
            // 
            // l7R
            // 
            this.l7R.AutoSize = true;
            this.l7R.Location = new System.Drawing.Point(463, 6);
            this.l7R.Name = "l7R";
            this.l7R.Size = new System.Drawing.Size(39, 13);
            this.l7R.TabIndex = 34;
            this.l7R.Text = "R: 255";
            // 
            // l6B
            // 
            this.l6B.AutoSize = true;
            this.l6B.Location = new System.Drawing.Point(392, 31);
            this.l6B.Name = "l6B";
            this.l6B.Size = new System.Drawing.Size(38, 13);
            this.l6B.TabIndex = 33;
            this.l6B.Text = "B: 255";
            // 
            // l6G
            // 
            this.l6G.AutoSize = true;
            this.l6G.Location = new System.Drawing.Point(392, 19);
            this.l6G.Name = "l6G";
            this.l6G.Size = new System.Drawing.Size(39, 13);
            this.l6G.TabIndex = 32;
            this.l6G.Text = "G: 255";
            // 
            // l6R
            // 
            this.l6R.AutoSize = true;
            this.l6R.Location = new System.Drawing.Point(392, 6);
            this.l6R.Name = "l6R";
            this.l6R.Size = new System.Drawing.Size(39, 13);
            this.l6R.TabIndex = 31;
            this.l6R.Text = "R: 255";
            // 
            // l5B
            // 
            this.l5B.AutoSize = true;
            this.l5B.Location = new System.Drawing.Point(320, 31);
            this.l5B.Name = "l5B";
            this.l5B.Size = new System.Drawing.Size(38, 13);
            this.l5B.TabIndex = 30;
            this.l5B.Text = "B: 255";
            // 
            // l5G
            // 
            this.l5G.AutoSize = true;
            this.l5G.Location = new System.Drawing.Point(320, 19);
            this.l5G.Name = "l5G";
            this.l5G.Size = new System.Drawing.Size(39, 13);
            this.l5G.TabIndex = 29;
            this.l5G.Text = "G: 255";
            // 
            // l5R
            // 
            this.l5R.AutoSize = true;
            this.l5R.Location = new System.Drawing.Point(320, 6);
            this.l5R.Name = "l5R";
            this.l5R.Size = new System.Drawing.Size(39, 13);
            this.l5R.TabIndex = 28;
            this.l5R.Text = "R: 255";
            // 
            // l4B
            // 
            this.l4B.AutoSize = true;
            this.l4B.Location = new System.Drawing.Point(250, 31);
            this.l4B.Name = "l4B";
            this.l4B.Size = new System.Drawing.Size(38, 13);
            this.l4B.TabIndex = 27;
            this.l4B.Text = "B: 255";
            // 
            // l4G
            // 
            this.l4G.AutoSize = true;
            this.l4G.Location = new System.Drawing.Point(250, 19);
            this.l4G.Name = "l4G";
            this.l4G.Size = new System.Drawing.Size(39, 13);
            this.l4G.TabIndex = 26;
            this.l4G.Text = "G: 255";
            // 
            // l4R
            // 
            this.l4R.AutoSize = true;
            this.l4R.Location = new System.Drawing.Point(250, 6);
            this.l4R.Name = "l4R";
            this.l4R.Size = new System.Drawing.Size(39, 13);
            this.l4R.TabIndex = 25;
            this.l4R.Text = "R: 255";
            // 
            // l3B
            // 
            this.l3B.AutoSize = true;
            this.l3B.Location = new System.Drawing.Point(180, 31);
            this.l3B.Name = "l3B";
            this.l3B.Size = new System.Drawing.Size(38, 13);
            this.l3B.TabIndex = 24;
            this.l3B.Text = "B: 255";
            // 
            // l3G
            // 
            this.l3G.AutoSize = true;
            this.l3G.Location = new System.Drawing.Point(180, 19);
            this.l3G.Name = "l3G";
            this.l3G.Size = new System.Drawing.Size(39, 13);
            this.l3G.TabIndex = 23;
            this.l3G.Text = "G: 255";
            // 
            // l3R
            // 
            this.l3R.AutoSize = true;
            this.l3R.Location = new System.Drawing.Point(180, 6);
            this.l3R.Name = "l3R";
            this.l3R.Size = new System.Drawing.Size(39, 13);
            this.l3R.TabIndex = 22;
            this.l3R.Text = "R: 255";
            // 
            // l2B
            // 
            this.l2B.AutoSize = true;
            this.l2B.Location = new System.Drawing.Point(108, 31);
            this.l2B.Name = "l2B";
            this.l2B.Size = new System.Drawing.Size(38, 13);
            this.l2B.TabIndex = 21;
            this.l2B.Text = "B: 255";
            // 
            // l2G
            // 
            this.l2G.AutoSize = true;
            this.l2G.Location = new System.Drawing.Point(108, 19);
            this.l2G.Name = "l2G";
            this.l2G.Size = new System.Drawing.Size(39, 13);
            this.l2G.TabIndex = 20;
            this.l2G.Text = "G: 255";
            // 
            // l2R
            // 
            this.l2R.AutoSize = true;
            this.l2R.Location = new System.Drawing.Point(108, 6);
            this.l2R.Name = "l2R";
            this.l2R.Size = new System.Drawing.Size(39, 13);
            this.l2R.TabIndex = 19;
            this.l2R.Text = "R: 255";
            // 
            // l1B
            // 
            this.l1B.AutoSize = true;
            this.l1B.Location = new System.Drawing.Point(36, 31);
            this.l1B.Name = "l1B";
            this.l1B.Size = new System.Drawing.Size(38, 13);
            this.l1B.TabIndex = 18;
            this.l1B.Text = "B: 255";
            // 
            // l1G
            // 
            this.l1G.AutoSize = true;
            this.l1G.Location = new System.Drawing.Point(36, 19);
            this.l1G.Name = "l1G";
            this.l1G.Size = new System.Drawing.Size(39, 13);
            this.l1G.TabIndex = 17;
            this.l1G.Text = "G: 255";
            // 
            // l1R
            // 
            this.l1R.AutoSize = true;
            this.l1R.Location = new System.Drawing.Point(36, 6);
            this.l1R.Name = "l1R";
            this.l1R.Size = new System.Drawing.Size(39, 13);
            this.l1R.TabIndex = 16;
            this.l1R.Text = "R: 255";
            // 
            // pColor16
            // 
            this.pColor16.Location = new System.Drawing.Point(503, 60);
            this.pColor16.Name = "pColor16";
            this.pColor16.Size = new System.Drawing.Size(30, 40);
            this.pColor16.TabIndex = 15;
            this.pColor16.TabStop = false;
            // 
            // pColor15
            // 
            this.pColor15.Location = new System.Drawing.Point(432, 60);
            this.pColor15.Name = "pColor15";
            this.pColor15.Size = new System.Drawing.Size(30, 40);
            this.pColor15.TabIndex = 14;
            this.pColor15.TabStop = false;
            // 
            // pColor14
            // 
            this.pColor14.Location = new System.Drawing.Point(361, 60);
            this.pColor14.Name = "pColor14";
            this.pColor14.Size = new System.Drawing.Size(30, 40);
            this.pColor14.TabIndex = 13;
            this.pColor14.TabStop = false;
            // 
            // pColor13
            // 
            this.pColor13.Location = new System.Drawing.Point(289, 60);
            this.pColor13.Name = "pColor13";
            this.pColor13.Size = new System.Drawing.Size(30, 40);
            this.pColor13.TabIndex = 12;
            this.pColor13.TabStop = false;
            // 
            // pColor12
            // 
            this.pColor12.Location = new System.Drawing.Point(219, 60);
            this.pColor12.Name = "pColor12";
            this.pColor12.Size = new System.Drawing.Size(30, 40);
            this.pColor12.TabIndex = 11;
            this.pColor12.TabStop = false;
            // 
            // pColor11
            // 
            this.pColor11.Location = new System.Drawing.Point(148, 60);
            this.pColor11.Name = "pColor11";
            this.pColor11.Size = new System.Drawing.Size(30, 40);
            this.pColor11.TabIndex = 10;
            this.pColor11.TabStop = false;
            // 
            // pColor10
            // 
            this.pColor10.Location = new System.Drawing.Point(76, 60);
            this.pColor10.Name = "pColor10";
            this.pColor10.Size = new System.Drawing.Size(30, 40);
            this.pColor10.TabIndex = 9;
            this.pColor10.TabStop = false;
            // 
            // pColor9
            // 
            this.pColor9.Location = new System.Drawing.Point(4, 60);
            this.pColor9.Name = "pColor9";
            this.pColor9.Size = new System.Drawing.Size(30, 40);
            this.pColor9.TabIndex = 8;
            this.pColor9.TabStop = false;
            // 
            // pColor8
            // 
            this.pColor8.Location = new System.Drawing.Point(503, 4);
            this.pColor8.Name = "pColor8";
            this.pColor8.Size = new System.Drawing.Size(30, 40);
            this.pColor8.TabIndex = 7;
            this.pColor8.TabStop = false;
            // 
            // pColor7
            // 
            this.pColor7.Location = new System.Drawing.Point(432, 4);
            this.pColor7.Name = "pColor7";
            this.pColor7.Size = new System.Drawing.Size(30, 40);
            this.pColor7.TabIndex = 6;
            this.pColor7.TabStop = false;
            // 
            // pColor6
            // 
            this.pColor6.Location = new System.Drawing.Point(361, 4);
            this.pColor6.Name = "pColor6";
            this.pColor6.Size = new System.Drawing.Size(30, 40);
            this.pColor6.TabIndex = 5;
            this.pColor6.TabStop = false;
            // 
            // pColor5
            // 
            this.pColor5.Location = new System.Drawing.Point(289, 4);
            this.pColor5.Name = "pColor5";
            this.pColor5.Size = new System.Drawing.Size(30, 40);
            this.pColor5.TabIndex = 4;
            this.pColor5.TabStop = false;
            // 
            // pColor4
            // 
            this.pColor4.Location = new System.Drawing.Point(219, 4);
            this.pColor4.Name = "pColor4";
            this.pColor4.Size = new System.Drawing.Size(30, 40);
            this.pColor4.TabIndex = 3;
            this.pColor4.TabStop = false;
            // 
            // pColor3
            // 
            this.pColor3.Location = new System.Drawing.Point(148, 4);
            this.pColor3.Name = "pColor3";
            this.pColor3.Size = new System.Drawing.Size(30, 40);
            this.pColor3.TabIndex = 2;
            this.pColor3.TabStop = false;
            // 
            // pColor2
            // 
            this.pColor2.Location = new System.Drawing.Point(76, 4);
            this.pColor2.Name = "pColor2";
            this.pColor2.Size = new System.Drawing.Size(30, 40);
            this.pColor2.TabIndex = 1;
            this.pColor2.TabStop = false;
            // 
            // pColor1
            // 
            this.pColor1.Location = new System.Drawing.Point(4, 4);
            this.pColor1.Name = "pColor1";
            this.pColor1.Size = new System.Drawing.Size(30, 40);
            this.pColor1.TabIndex = 0;
            this.pColor1.TabStop = false;
            // 
            // bImportPNG
            // 
            this.bImportPNG.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.bImportPNG.Image = ((System.Drawing.Image)(resources.GetObject("bImportPNG.Image")));
            this.bImportPNG.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.bImportPNG.Name = "bImportPNG";
            this.bImportPNG.Size = new System.Drawing.Size(74, 22);
            this.bImportPNG.Text = "Import PNG";
            this.bImportPNG.Click += new System.EventHandler(this.bImportPNG_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(871, 659);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Shown += new System.EventHandler(this.Form1_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.splitContainer2.Panel1.ResumeLayout(false);
            this.splitContainer2.Panel2.ResumeLayout(false);
            this.splitContainer2.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer2)).EndInit();
            this.splitContainer2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pColor16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pColor1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tStatusCurrentFile;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.ListBox lbFiles;
        private System.Windows.Forms.ToolStripButton bOpenDir;
        private System.Windows.Forms.ToolStripButton bExportBmp;
        private System.Windows.Forms.SplitContainer splitContainer2;
        internal System.Windows.Forms.PictureBox pColor1;
        internal System.Windows.Forms.PictureBox pColor16;
        internal System.Windows.Forms.PictureBox pColor15;
        internal System.Windows.Forms.PictureBox pColor14;
        internal System.Windows.Forms.PictureBox pColor13;
        internal System.Windows.Forms.PictureBox pColor12;
        internal System.Windows.Forms.PictureBox pColor11;
        internal System.Windows.Forms.PictureBox pColor10;
        internal System.Windows.Forms.PictureBox pColor9;
        internal System.Windows.Forms.PictureBox pColor8;
        internal System.Windows.Forms.PictureBox pColor7;
        internal System.Windows.Forms.PictureBox pColor6;
        internal System.Windows.Forms.PictureBox pColor5;
        internal System.Windows.Forms.PictureBox pColor4;
        internal System.Windows.Forms.PictureBox pColor3;
        internal System.Windows.Forms.PictureBox pColor2;
        internal System.Windows.Forms.Label l1B;
        internal System.Windows.Forms.Label l1G;
        internal System.Windows.Forms.Label l1R;
        internal System.Windows.Forms.Label l8B;
        internal System.Windows.Forms.Label l8G;
        internal System.Windows.Forms.Label l8R;
        internal System.Windows.Forms.Label l7B;
        internal System.Windows.Forms.Label l7G;
        internal System.Windows.Forms.Label l7R;
        internal System.Windows.Forms.Label l6B;
        internal System.Windows.Forms.Label l6G;
        internal System.Windows.Forms.Label l6R;
        internal System.Windows.Forms.Label l5B;
        internal System.Windows.Forms.Label l5G;
        internal System.Windows.Forms.Label l5R;
        internal System.Windows.Forms.Label l4B;
        internal System.Windows.Forms.Label l4G;
        internal System.Windows.Forms.Label l4R;
        internal System.Windows.Forms.Label l3B;
        internal System.Windows.Forms.Label l3G;
        internal System.Windows.Forms.Label l3R;
        internal System.Windows.Forms.Label l2B;
        internal System.Windows.Forms.Label l2G;
        internal System.Windows.Forms.Label l2R;
        internal System.Windows.Forms.Label l16B;
        internal System.Windows.Forms.Label l16G;
        internal System.Windows.Forms.Label l16R;
        internal System.Windows.Forms.Label l15B;
        internal System.Windows.Forms.Label l15G;
        internal System.Windows.Forms.Label l15R;
        internal System.Windows.Forms.Label l14B;
        internal System.Windows.Forms.Label l14G;
        internal System.Windows.Forms.Label l14R;
        internal System.Windows.Forms.Label l13B;
        internal System.Windows.Forms.Label l13G;
        internal System.Windows.Forms.Label l13R;
        internal System.Windows.Forms.Label l12B;
        internal System.Windows.Forms.Label l12G;
        internal System.Windows.Forms.Label l12R;
        internal System.Windows.Forms.Label l11B;
        internal System.Windows.Forms.Label l11G;
        internal System.Windows.Forms.Label l11R;
        internal System.Windows.Forms.Label l10B;
        internal System.Windows.Forms.Label l10G;
        internal System.Windows.Forms.Label l10R;
        internal System.Windows.Forms.Label l9B;
        internal System.Windows.Forms.Label l9G;
        internal System.Windows.Forms.Label l9R;
        private System.Windows.Forms.ToolStripButton bCompile;
        private System.Windows.Forms.ToolStripButton bImportPNG;
    }
}

