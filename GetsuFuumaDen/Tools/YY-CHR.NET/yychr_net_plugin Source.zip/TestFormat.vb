﻿Imports System
Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports CharactorLib.Common
Imports CharactorLib.Format
Namespace TestPlugin
    Public Class TestFormat
        Inherits FormatBase
        ''' <summary>
        ''' Constructor.
        ''' </summary>
        Public Sub New()
            MyBase.FormatText = "[8][8]"
            MyBase.Name = "VB TestFormat"
            MyBase.Extension = "VB test"
            MyBase.Author = "Yy"
            MyBase.Url = "http://test.jp/index.html"
            'Flags
            MyBase.Readonly = False
            MyBase.IsCompressed = False
            MyBase.EnableAdf = True
            MyBase.IsSupportMirror = True
            MyBase.IsSupportRotate = True
            'Settings
            MyBase.ColorBit = 2
            MyBase.ColorNum = 4
            MyBase.CharWidth = 8
            MyBase.CharHeight = 8
            'Settings for Image Convert
            MyBase.Width = 128
            MyBase.Height = 128
        End Sub
        ''' <summary>
        ''' データのアドレスを取得する。
        ''' ex)NESならヘッダを読む。
        ''' </summary>
        ''' <param name="data">全データ</param>
        ''' <returns>アドレス</returns>
        Public Overrides Function GetDataAddress(ByVal data As Byte()) As Integer
            Dim addr As Integer = 0
            If ((data IsNot Nothing) And (data.Length > &H10)) Then
                'NESヘッダを読む
                If ((data(0) = &H4E) And (data(1) = &H45) And (data(2) = &H53) And (data(3) = &H1A)) Then
                    Dim prg As Byte = data(4)
                    Dim chrx As Byte = data(5)
                    If (chrx > 0) Then
                        ' CHR在りの場合、PRGのサイズ以降がCHRのアドレス
                        addr = prg * &H4000
                    Else
                        ' CHR無しの場合
                        addr = 0
                    End If
                    ' NESヘッダアドレスを加算
                    addr += &H10
                End If
            End If

            Return addr
        End Function
        ''' <summary>
        ''' Charactor Convert.
        ''' </summary>
        ''' <param name="data">Data</param>
        ''' <param name="addr">Data address</param>
        ''' <param name="bytemap">Bytemap</param>
        ''' <param name="px">Bytemap position X</param>
        ''' <param name="py">Bytemap position Y</param>
        Public Overrides Sub ConvertMemToChr(ByVal data As Byte(), ByVal addr As Integer, ByVal bytemap As Bytemap, ByVal px As Integer, ByVal py As Integer)
            ' 8ライン展開
            For y = 0 To CharHeight - 1
                Dim l0Addr As Integer = y + addr
                Dim l1Addr As Integer = l0Addr + &H8
                Dim l0 As Byte = data(l0Addr)
                Dim l1 As Byte = data(l1Addr)
                '8ドット展開
                For x = 0 To CharWidth - 1
                    Dim v0 As Byte = CByte((l0 >> (7 - x)) And &H1)
                    Dim v1 As Byte = CByte((l1 >> (7 - x)) And &H1)
                    Dim value As Byte = CByte((v1 << 1) Or v0)
                    Dim p As Point = MyBase.GetAdvancePixelPoint(px + x, py + y)
                    Dim bytemapAddr As Integer = bytemap.GetPointAddress(p.X, p.Y)
                    bytemap.Data(bytemapAddr) = value
                Next
            Next
        End Sub
        ''' <summary>
        ''' Charactor Convert.
        ''' </summary>
        ''' <param name="data">Data</param>
        ''' <param name="addr">Data address</param>
        ''' <param name="bytemap">Bytemap</param>
        ''' <param name="px">Bytemap position X</param>
        ''' <param name="py">Bytemap position Y</param>
        Public Overrides Sub ConvertChrToMem(ByVal data As Byte(), ByVal addr As Integer, ByVal bytemap As Bytemap, ByVal px As Integer, ByVal py As Integer)
            ' 8ライン更新
            For y = 0 To CharHeight - 1
                Dim l0Addr As Integer = y + addr
                Dim l1Addr As Integer = l0Addr + &H8
                Dim l0 As Byte = 0
                Dim l1 As Byte = 0
                '8ドット展開
                For x = 0 To CharWidth - 1
                    Dim p As Point = MyBase.GetAdvancePixelPoint(px + x, py + y)
                    Dim bytemapAddr As Integer = bytemap.GetPointAddress(p.X, p.Y)
                    Dim value As Byte = bytemap.Data(bytemapAddr)
                    Dim p0 As Integer = (value >> 0) And 1
                    Dim p1 As Integer = (value >> 1) And 1
                    l0 = l0 Or CByte(p0 << (7 - x))
                    l1 = l1 Or CByte(p1 << (7 - x))
                Next
                data(l0Addr) = l0
                data(l1Addr) = l1
            Next
        End Sub
    End Class
End Namespace

